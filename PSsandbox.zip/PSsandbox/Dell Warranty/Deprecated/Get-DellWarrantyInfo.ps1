$DellAPIURL = "https://apigtwb2c.us.dell.com/PROD/sbil/eapi/v5/asset-entitlements"
$DellAPIKey      = "l75ebe2cd1bd3a44ff91d8f0be2faddb59"
$APIKeySecret    = 'd1bc9d4477fd449494a4a31f3ac11405'
$headers = @{
            Accept = "application/json"
            Authorization = "Bearer $script:token"
        }
$params = @{ servicetags = $ServiceTags -join ','}
$NewFileName = "Dell Warranty Report"+(Get-Date -Format MM-yyyy)+".csv"
$props=[ordered]@{
     Workstation=''
     Expires=''
}
New-Object PsObject -Property $props | Export-Csv C:\Temp\$NewFileName -NoTypeInformation
$servicetags = @(
"2GBPQN1"
"J5WF5P1"
"672PMN1"
)
Function Get-Token {
$AuthURI      = "https://apigtwb2c.us.dell.com/auth/oauth/v2/token"
    $OAuth        = "$DellAPIKey`:$APIKeySecret"
    $Bytes        = [System.Text.Encoding]::ASCII.GetBytes($OAuth)
    $EncodedOAuth = [Convert]::ToBase64String($Bytes)

    $Headers = @{ }
    $Headers.Add("authorization", "Basic $EncodedOAuth")
    $Authbody = 'grant_type=client_credentials'
    
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    
    Try {
        $AuthResult = Invoke-RESTMethod -Method Post -Uri $AuthURI -Body $AuthBody -Headers $Headers
        $script:token = $AuthResult.access_token
    }
    Catch {
        $ErrorMessage = $Error[0]
        Write-Error $ErrorMessage
        BREAK        
    }
    Write-Verbose "Access Token is: $script:token"
}
Function Invoke-DellAPILookup {
param([string[]] $ServiceTags)
$headers = @{
Accept = "application/json"
Authorization = "Bearer $script:token"
}
$params = @{ servicetags = $ServiceTags -join ','}
$lookup = Invoke-RestMethod -Uri $DellAPIURL -Headers $headers -Body $params -Method Get -ContentType "application/json"
return $lookup
}
foreach ($tag in $servicetags){
$sdata = Invoke-DellAPILookup -ServiceTags $tag
$sdata | Select @{Name="Workstation";Expression={"WS-" + $sdata.ServiceTag}},@{Name="Expires";Expression={($sdata.Entitlements.EndDate|sort -Descending|select -First 1) -replace  "T\d\d:.+",""}}|Export-Csv C:\Temp\$NewFileName -NoTypeInformation -Append
}
