<#
    INSTRUCTIONS:

    1. Manually create the database table if it does not exist using this T-SQL in SQL Server Management Studio

        CREATE TABLE [dbo].[DellWarrantyInformation](
            [ServiceTag] [varchar](30) NOT NULL,
            [Region] [varchar](50) NULL,
            [LOB] [varchar](50) NULL,
            [SystemModel] [varchar](50) NULL,
            [ShipDate] [datetime] NULL,
            [ServiceLevelCode] [varchar](50) NULL,
            [ServiceLevelDescription] [varchar](255) NULL,
            [WarrantyStartDate] [datetime] NULL,
            [WarrantyEndDate] [datetime] NULL,
            [WarrantyDaysLeft] [int] NULL,
            [EntitlementType] [varchar](30) NULL,
            LastUpdated [datetime] NULL
        ) ON [PRIMARY]

    2. Grant the user account that will execute this script permissions to the database/table (Write or DBO)

    3. Configure this script in the '#region CONFIG' area

    4. Create a scheduled task on your SCCM server to run this nightly
#>


#====================================================================================================================\
# PURPOSE:
#    Perform bulk lookups against the Dell v5 API and add this data to the SCCM database.
#
# REQUIREMENTS:
#    Powershell 4.0 or higher, SqlServer Powershell Module
#
# NOTE:
#    Lookups include up to 20 Dell Service Tags each; and there is a 2-second pause between each lookup to avoid
#    exceeding API limitations.
#====================================================================================================================/


#region CONFIG

    $CMSiteCode      = "<site code>"
    $CMServerFQDN    = "<IP or FQDN of SCCM DB server>"
    $DellAPIKey      = "l75ebe2cd1bd3a44ff91d8f0be2faddb59"
    $APIKeySecret    = 'd1bc9d4477fd449494a4a31f3ac11405'

    $RefreshInterval = 90   # Refresh warranty information after it is more than this many days old
    $RefreshCount    = 50   # Only refresh this many service tags at once

#endregion


#====================================================================================================================\
# No need to edit below this line
#====================================================================================================================/


#region INITIALIZE

    $CMDatabaseName    = "CM_$CMSiteCode"
    $script:DellAPIURL = "https://apigtwb2c.us.dell.com/PROD/sbil/eapi/v5/asset-entitlements"
    
    if ($host.Name -ne 'ConsoleHost')
    {
        $VerbosePreference = "Continue"
    }

#endregion


#region IMPORT MODULES

    Import-Module SqlServer -DisableNameChecking

#endregion


#region FUNCTIONS

    Function Invoke-CacheData
    {
        Param($DellData)
        ForEach($Asset in $DellData)
        {
            $Asset | Format-Table -HideTableHeaders | Out-String | Write-Verbose
            foreach($Item in ($Asset.entitlements | Where-Object { $_.ServiceLevelDescription -like "*Support*" }))
            {
                $Row = $Script:WarrantyEntries.NewRow()
                $Row["ServiceTag"] = $Asset.serviceTag
                $Row["Region"] = $Asset.countryCode
                $Row["LOB"] = $Asset.productLobDescription
                $Row["SystemModel"] = $Asset.systemDescription
                $Row["ShipDate"] = [DateTime]$Asset.shipDate
                $DaysRemaining = [int](New-Timespan -Start (Get-Date) -End ([datetime]$Item.endDate)).Days
                If($DaysRemaining -lt 0){ $DaysRemaining = 0 }
                $Row["ServiceLevelCode"] = $Item.serviceLevelCode
                $Row["ServiceLevelDescription"] = $Item.serviceLevelDescription
                $Row["WarrantyStartDate"] = [DateTime]$Item.startDate
                $Row["WarrantyEndDate"] = [DateTime]$item.endDate
                $Row["WarrantyDaysLeft"] = $DaysRemaining
                $Row["EntitlementType"] = $Item.entitlementType
                $Row["LastUpdated"] = [datetime](Get-Date)
                $Script:WarrantyEntries.Rows.Add($Row) | Out-Null
            }
        }
    }

    Function Invoke-DellAPILookup
    {
        param([string[]] $ServiceTags)
        
        $headers = @{
            Accept = "application/json"
            Authorization = "Bearer $script:token"
        }
        
        $params = @{ servicetags = $ServiceTags -join ','}

        $lookup = Invoke-RestMethod -Uri $DellAPIURL -Headers $headers -Body $params -Method Get -ContentType "application/json"

        return $lookup
    }


#endregion


#region DATA TABLE

    $Script:WarrantyEntries = New-Object System.Data.DataTable("Temp")
    $StringColumns = @("ServiceTag","Region","LOB","SystemModel","ShipDate","ServiceLevelCode","ServiceLevelDescription","WarrantyStartDate","WarrantyEndDate","WarrantyDaysLeft","EntitlementType","LastUpdated")
    ForEach($Column in $StringColumns){
        $Script:WarrantyEntries.Columns.Add($Column) | Out-Null
    }

#endregion

#region API Authentication
    $AuthURI      = "https://apigtwb2c.us.dell.com/auth/oauth/v2/token"
    $OAuth        = "$DellAPIKey`:$APIKeySecret"
    $Bytes        = [System.Text.Encoding]::ASCII.GetBytes($OAuth)
    $EncodedOAuth = [Convert]::ToBase64String($Bytes)

    $Headers = @{ }
    $Headers.Add("authorization", "Basic $EncodedOAuth")
    $Authbody = 'grant_type=client_credentials'
    
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    
    Try {
        $AuthResult = Invoke-RESTMethod -Method Post -Uri $AuthURI -Body $AuthBody -Headers $Headers
        $script:token = $AuthResult.access_token
    }
    Catch {
        $ErrorMessage = $Error[0]
        Write-Error $ErrorMessage
        BREAK        
    }
    Write-Verbose "Access Token is: $script:token"
#endregion


#region API RETREIVAL

    $QueryTags = @()
    # Remove stale warranty information for refreshing
    $sqlcmd = @"
        DELETE FROM DellWarrantyInformation
        WHERE ServiceTag in
        (
            SELECT DISTINCT TOP $RefreshCount ServiceTag
            FROM DellWarrantyInformation
            WHERE LastUpdated IS NULL OR LastUpdated < DATEADD(day, -$RefreshInterval, GETDATE())
        )
"@
    Invoke-Sqlcmd -Query $sqlcmd -Database $CMDatabaseName -ServerInstance $CMServerFQDN
    
    # Retreive all Dell Service tags from SCCM and known warranty information from SQL
    $DellServiceTags = Get-WmiObject -ComputerName $CMServerFQDN -Namespace "Root\SMS\Site_$CMSiteCode" -Class SMS_G_System_SYSTEM_ENCLOSURE  -Filter "Manufacturer LIKE '%Dell%'" | Select-Object -ExpandProperty Serialnumber -Unique
    $KnownServiceTags = @(Invoke-Sqlcmd -Query "SELECT DISTINCT ServiceTag FROM DellWarrantyInformation" -Database $CMDatabaseName -ServerInstance $CMServerFQDN) | Select-Object -ExpandProperty ServiceTag -Unique

    $i = 0

    ForEach($ServiceTag in $DellServiceTags)
    {
        $i++

        #Is warranty information on this service tag already known?
        if (-not $KnownServiceTags.Contains($ServiceTag))
        {
            #Tag isn't known - add it to the list to look up
            $QueryTags += $ServiceTag
            Write-Verbose "VERBOSE: Unknown Service Tag: $ServiceTag"

            # Have we got 20 tags to look up?
            If($QueryTags.Count -ge 20)
            { 
                # Yes - look up these tags
                $results = Invoke-DellAPILookup -ServiceTags $QueryTags
                Invoke-CacheData -DellData $results
                Start-Sleep -Seconds 2

                $QueryTags = @()

                Write-Verbose "Processed $i of $($DellServiceTags.Count) assets"
            }
        }
    }

    # Finished looking up new tags - are there any left over to look up?
    If($QueryTags.Count -gt 0)
    {
        # Yes, look these up too.
        $results = Invoke-DellAPILookup -ServiceTags $QueryTags
        Invoke-CacheData -DellData $results
    }

#endregion
  

#region SQL

    #Insert new entries to the database
    If($Script:WarrantyEntries.Rows.Count -gt 0)
    {
        $DBCon = New-Object System.Data.SqlClient.SqlConnection("Data Source=$CMServerFQDN;Integrated Security=True;Initial Catalog=$CMDatabaseName");
        $DBCon.Open()
        $BulkCopy = New-Object System.Data.SqlClient.SqlBulkCopy($DBCon)
        $BulkCopy.DestinationTableName = "dbo.DellWarrantyInformation"
        $BulkCopy.BulkCopyTimeout = 0
        $BulkCopy.BatchSize = 1000
        $BulkCopy.WriteToServer($Script:WarrantyEntries)
        $BulkCopy.Close();
        $DBCon.Close()
    }

#endregion


#region CLEAN UP

    $Script:WarrantyEntries.Dispose()
    $BulkCopy.Dispose()
    [System.GC]::Collect()
    Set-Location C:
    Exit

#endregion