Use PowerShell to get Dell warranty information directly from Dell through their Dell Warranty Status API. This information can be used to feed an AssetManagement system, ticketing system or any other CMDB.

More information can be found here: https://systemcentertipps.wordpress.com/2016/09/09/getting-dell-warranty-information

 

PowerShell
#===========================================================================================  
# AUTHOR:         Natascia Heil 
# Script Name:    GetDellWarrantyInfo.ps1  
# DATE:           09/09/2016 
# Version:        1.0  
# COMMENT:        - Script to check Warranty information for a computer from the  
#                 Dell Warranty Status API 
# Example:        .\GetDellWarrantyInfo.ps1 -ServiceTag '1a2b3c' -ApiKey "sdfj7122394057sdfiouwer" -Dev $true 
#===========================================================================================  
 
Param(  
 
[Parameter(Mandatory=$true)]  
[String]$ServiceTag, 
[Parameter(Mandatory=$true)]  
[String]$ApiKey, 
[Parameter(Mandatory=$true)]  
[Bool]$Dev 
) 
 
#Build URL 
If ($Dev) 
{ 
$URL1 = "https://sandbox.api.dell.com/support/assetinfo/v4/getassetwarranty/$ServiceTag"  
} 
else 
{ 
$URL1 = "https://api.dell.com/support/assetinfo/v4/getassetwarranty/$ServiceTag"  
} 
$URL2 = "?apikey=$Apikey"  
$URL = $URL1 + $URL2  
 
# Get Data 
$Request = Invoke-RestMethod -URI $URL -Method GET -contenttype 'Application/xml'  
 
# Extract Warranty Info 
$Warranty=$Request.AssetWarrantyDTO.AssetWarrantyResponse.AssetWarrantyResponse.AssetEntitlementData.AssetEntitlement|where ServiceLevelDescription -NE 'Dell Digitial Delivery'  
 
# Read first entry if available 
If ($Warranty -is [Object])  
{  
    $SLA=$Warranty[0].ServiceLevelDescription  
    $EndDate=$Warranty[0].EndDate  
}  
else  
{  
$SLA='Expired'  
}  
 