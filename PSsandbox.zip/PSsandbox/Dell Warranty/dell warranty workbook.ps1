$APIKEY = 'l75ebe2cd1bd3a44ff91d8f0be2faddb59'
$URL = 'https://api.dell.com/support/v2/assetinfo/warranty/tags.json?svctags={0}&apikey=' + APIKEY
$Server = "https://api.dell.com/support/assetinfo/v4/getassetwarranty/"  
$Warranty = Invoke-RestMethod -URI $URL -Method GET -ContentType 'Application/xml' 
$URI = $Server + $SubmitTags + "?apikey=" + $Apikey 
$ServiceTag = "4bf85q2"
#$URL1 = "https://sandbox.api.dell.com/support/assetinfo/v4/getassetwarranty/$ServiceTag"  
$URL1 = "https://api.dell.com/support/assetinfo/v4/getassetwarranty/$ServiceTag"  

$URL2 = "?apikey=$Apikey"  
$URL = $URL1 + $URL2  
$Request = Invoke-RestMethod -URI $URL -Method GET -contenttype 'Application/xml'  
$Warranty=$Request.AssetWarrantyDTO.AssetWarrantyResponse.AssetWarrantyResponse.AssetEntitlementData.AssetEntitlement|where ServiceLevelDescription -NE 'Dell Digitial Delivery'  
#################################################
Function Get-DellAssetInfo([string]$ServiceTag){

$Asset=New-WebServiceProxy -Uri 'http://xserv.dell.com/services/AssetService.asmx?WSDL' -UseDefaultCredential
$Asset.GetAssetInformation([Guid]::NewGuid(),'AssetService',$ServiceTag);
}


$ComputerInfo = Get-WMIObject -Class "Win32_BIOS" -Computer $ComputerName | select Manufacturer, SerialNumber
$ComputerInfo = Get-WMIObject -Class "Win32_BIOS" | select Manufacturer, SerialNumber
$ComputerSerial = $ComputerInfo | Select -Expand SerialNumber


$results=Get-DellAssetInfo $ComputerSerial

#I just put the different properties in variables, but you should use a custom object

$SystemType = $results.AssetHeaderData.SystemType
$ServiceLevelDescription = $results.Entitlements.ServiceLevelDescription
$SystemModel = $results.AssetHeaderData.SystemModel
$Region = $results.AssetHeaderData.Region         
$StartDate = $results.Entitlements.StartDate.Date | Select -ExpandProperty DateTime 
$EndDate = $results.Entitlements.EndDate.Date | Select -ExpandProperty DateTime  
#####################################################################
4BF85Q2 = 0-NjFCV09yODNKNUFpN1dqeDJZOTlWZz090

4BF85Q2
#######################################################################
foreach ($tag in $servicetags){
$sdata = Invoke-DellAPILookup -ServiceTags $tag
$name = "WS-" + $sdata.ServiceTag
$EndDate = $sdata.Entitlements.EndDate|sort -Descending|select -First 1
$NewLine = "$name -> $EndDate"
$NewLine = $NewLine -replace "T\d\d:.+",""
Add-Content $DataFile -Value $NewLine
}

foreach ($tag in $servicetags){
$sdata = Invoke-DellAPILookup -ServiceTags $tag
$sdata | Select @{Name="Workstation";Expression={"WS-" + $sdata.ServiceTag}},@{Name="Expires";Expression={($sdata.Entitlements.EndDate|sort -Descending|select -First 1) -replace  "T\d\d:.+",""}}|Export-Csv c:\Temp\myfile.csv -NoTypeInformation -Append
}
$NewFileName = "Dell Warranty Report"+(Get-Date -Format MM-yyyy)+".csv"
$props=[ordered]@{
     Workstation=''
     Expires=''
}
New-Object PsObject -Property $props | Export-Csv C:\Temp\$NewFileName -NoTypeInformation
... | Select @{Name="Workstation";Expression={$sdata.ServiceTag}},@{Name="Expires";Expression={$sdata.Entitlements.EndDate}} ... #and so on
$sdata | Select @{Name="Workstation";Expression={"WS-" + $sdata.ServiceTag}},@{Name="Expires";Expression={($sdata.Entitlements.EndDate|sort -Descending|select -First 1) -replace  "T\d\d:.+",""}}|Export-Csv c:\Temp\myfile.csv -NoTypeInformation -Append
###########################################################################
$Tagarray = @()
$computers = get-adcomputer -Filter * -Properties Name,Description,Enabled|where {$_.Enabled -eq $True}|select Name,Description
foreach ($C in $computers){
$wmidata = Get-WmiObject -ComputerName $C.Name -Class win32_bios -EA 0
IF ($wmidata.Manufacturer -like "Dell*"){$Tagarray = $Tagarray + $wmidata.SerialNumber}
}
$list2 = ($computers.name -match "WS-.......$") -replace "WS-",""
$Array2 = $Tagarray + $list2
$servicetags = ($array2 | select -Unique)
