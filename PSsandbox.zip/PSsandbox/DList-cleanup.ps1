#Get names of the AD distribution lists
$DistLists = Get-ADGroup -Filter *|where {$_.GroupCategory -eq "Distribution"}|select -expandproperty Name

#perform actions on each distribution list
foreach ($DL in $DistLists){

#Create Temporary list array of usernames for found disabled accounts to be removed 
$TempList = New-Object System.Collections.ArrayList 
#get listing of all users in group
$dlusers = Get-ADGroupMember $DL|select *
#Find the disabled users in the current list
foreach ($U in $dlusers){
$UName = Get-ADUser $U.SamAccountName -Properties * |select -expandproperty samaccountname
$UEnabled = Get-ADUser $U.SamAccountName -Properties * |select -expandproperty enabled
IF ($UEnabled -eq $false){$TempList.Add($UName)|out-null}}
#remove the disabled users from the current list
foreach ($DU in $TempList){
"Removing user $DU from list $DL"
Remove-ADGroupMember -Identity $DL -Members $DU -confirm:$false
}
}