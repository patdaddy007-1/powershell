function Check-FailedToUpdate {
<#

.SYNOPSIS
Check for failed update
.DESCRIPTION
check for failed update
.ROLE
Readers

#>
$fileContent = Get-Content $env:temp\InstallLog.txt -ErrorAction SilentlyContinue
if($null -eq $fileContent){
  return @{failedToUpdate = $false}
}
$file_data = Get-Content $env:temp\InstallLog.txt | Where-Object { $_ -like '*Windows Admin Center -- Installation completed successfully.*' }
if ( !$file_data) {
    return @{failedToUpdate = $true}
}
return @{failedToUpdate = $false}

}
## [END] Check-FailedToUpdate ##
function Disable-CredSspClientRole {
<#

.SYNOPSIS
Disables CredSSP on this client/gateway.

.DESCRIPTION
Disables CredSSP on this client/gateway.

.ROLE
Administrators

.Notes
The feature(s) that use this script are still in development and should be considered as being "In Preview".
Therefore, those feature(s) and/or this script may change at any time.

#>

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Setup all necessary global variables, constants, etc.

.DESCRIPTION
Setup all necessary global variables, constants, etc.

#>

function setupScriptEnv() {
    Set-Variable -Name WsManApplication -Option ReadOnly -Scope Script -Value "wsman"
    Set-Variable -Name CredSSPClientAuthPath -Option ReadOnly -Scope Script -Value "localhost\Client\Auth\CredSSP"
    Set-Variable -Name CredentialsDelegationPolicyPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation"
    Set-Variable -Name AllowFreshCredentialsPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentials"
    Set-Variable -Name AllowFreshCredentialsPropertyName -Option ReadOnly -Scope Script -Value "AllowFreshCredentials"
}

<#

.SYNOPSIS
Clean up all added global variables, constants, etc.

.DESCRIPTION
Clean up all added global variables, constants, etc.

#>

function cleanupScriptEnv() {
    Remove-Variable -Name WsManApplication -Scope Script -Force
    Remove-Variable -Name CredSSPClientAuthPath -Scope Script -Force
    Remove-Variable -Name CredentialsDelegationPolicyPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPropertyName -Scope Script -Force
}

<#

.SYNOPSIS
Is CredSSP client role enabled on this server.

.DESCRIPTION
When the CredSSP client role is enabled on this server then return $true.

#>

function getCredSSPClientEnabled() {
    $path = "{0}:\{1}" -f $WsManApplication, $CredSSPClientAuthPath

    $credSSPClientEnabled = $false;

    $credSSPClientService = Get-Item $path -ErrorAction SilentlyContinue
    if ($credSSPClientService) {
        $credSSPClientEnabled = [System.Convert]::ToBoolean($credSSPClientService.Value)
    }

    return $credSSPClientEnabled
}

<#

.SYNOPSIS
Disable CredSSP

.DESCRIPTION
Attempt to disable the CredSSP Client role and return any error that occurs

#>

function disableCredSSP() {
    $err = $null

    # Catching the result so that we can discard it. Otherwise it get concatinated with $err and we don't want that!
    $result = Disable-WSManCredSSP -Role Client -ErrorAction SilentlyContinue -ErrorVariable +err

    return $err
}

<#

.SYNOPSIS
Main function.

.DESCRIPTION
Main function.

#>

function main() {
    setupScriptEnv
    $results = $null

    # If the client role is disabled then we can stop.
    if (-not (getCredSSPClientEnabled)) {
        $results = $true
    } else {
        $err = disableCredSSP

        if ($err) {
            # If there is an error and the client role is not enabled return success.
            if (-not (getCredSSPClientEnabled)) {
                $results = $true
            }

            Write-Error @($err)[0]
            $results = $false
        }
    }

    cleanupScriptEnv

    return $results
}

###############################################################################
# SCcript execution starts here...
###############################################################################
$results = $null

if (-not ($env:pester)) {
    $results = main
}


return $results
    
}
## [END] Disable-CredSspClientRole ##
function Disable-CredSspManagedServer {
<#

.SYNOPSIS
Disables CredSSP on this server.

.DESCRIPTION
Disables CredSSP on this server.

.ROLE
Administrators

.Notes
The feature(s) that use this script are still in development and should be considered as being "In Preview".
Therefore, those feature(s) and/or this script may change at any time.

#>

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Is CredSSP client role enabled on this server.

.DESCRIPTION
When the CredSSP client role is enabled on this server then return $true.

#>

function getCredSSPClientEnabled() {
    Set-Variable credSSPClientPath -Option Constant -Value "WSMan:\localhost\Client\Auth\CredSSP" -ErrorAction SilentlyContinue

    $credSSPClientEnabled = $false;

    $credSSPClientService = Get-Item $credSSPClientPath -ErrorAction SilentlyContinue
    if ($credSSPClientService) {
        $credSSPClientEnabled = [System.Convert]::ToBoolean($credSSPClientService.Value)
    }

    return $credSSPClientEnabled
}

<#

.SYNOPSIS
Disable CredSSP

.DESCRIPTION
Attempt to disable the CredSSP Client role and return any error that occurs

#>

function disableCredSSPClientRole() {
    $err = $null

    # Catching the result so that we can discard it. Otherwise it get concatinated with $err and we don't want that!
    $result = Disable-WSManCredSSP -Role Client -ErrorAction SilentlyContinue -ErrorVariable +err

    return $err
}

<#

.SYNOPSIS
Disable the CredSSP client role on this server.

.DESCRIPTION
Disable the CredSSP client role on this server.

#>

function disableCredSSPClient() {
    # If disabled then we can stop.
    if (-not (getCredSSPClientEnabled)) {
        return $null
    }

    $err = disableCredSSPClientRole

    # If there is an error and it is not enabled, then success
    if ($err) {
        if (-not (getCredSSPClientEnabled)) {
            return $null
        }

        return $err
    }

    return $null
}

<#

.SYNOPSIS
Is CredSSP server role enabled on this server.

.DESCRIPTION
When the CredSSP server role is enabled on this server then return $true.

#>

function getCredSSPServerEnabled() {
    Set-Variable credSSPServicePath -Option Constant -Value "WSMan:\localhost\Service\Auth\CredSSP" -ErrorAction SilentlyContinue

    $credSSPServerEnabled = $false;

    $credSSPServerService = Get-Item $credSSPServicePath -ErrorAction SilentlyContinue
    if ($credSSPServerService) {
        $credSSPServerEnabled = [System.Convert]::ToBoolean($credSSPServerService.Value)
    }

    return $credSSPServerEnabled
}

<#

.SYNOPSIS
Disable CredSSP

.DESCRIPTION
Attempt to disable the CredSSP Server role and return any error that occurs

#>

function disableCredSSPServerRole() {
    $err = $null

    # Catching the result so that we can discard it. Otherwise it get concatinated with $err and we don't want that!
    $result = Disable-WSManCredSSP -Role Server -ErrorAction SilentlyContinue -ErrorVariable +err

    return $err
}

function disableCredSSPServer() {
    # If not enabled then we can leave
    if (-not (getCredSSPServerEnabled)) {
        return $null
    }

    $err = disableCredSSPServerRole

    # If there is an error, but the requested functionality completed don't fail the operation.
    if ($err) {
        if (-not (getCredSSPServerEnabled)) {
            return $null
        }

        return $err
    }
    
    return $null
}

<#

.SYNOPSIS
Main function.

.DESCRIPTION
Main function.

#>

function main() {
    $err = disableCredSSPServer
    if ($err) {
        throw $err
    }

    $err = disableCredSSPClient
    if ($err) {
        throw $err
    }

    return $true
}

###############################################################################
# Script execution starts here...
###############################################################################

if (-not ($env:pester)) {
    return main
}

}
## [END] Disable-CredSspManagedServer ##
function Enable-CredSSPClientRole {
<#

.SYNOPSIS
Enables CredSSP on this computer as client role to the other computer.

.DESCRIPTION
Enables CredSSP on this computer as client role to the other computer.

.ROLE
Administrators

.PARAMETER serverNames
The names of the server to which this gateway can forward credentials.

.LINK
https://portal.msrc.microsoft.com/en-us/security-guidance/advisory/CVE-2018-0886

.LINK
https://aka.ms/CredSSP-Updates

#>

param (
    [Parameter(Mandatory=$True)]
    [string[]]$serverNames
)

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Setup all necessary global variables, constants, etc.

.DESCRIPTION
Setup all necessary global variables, constants, etc.

#>

function setupScriptEnv() {
    Set-Variable -Name WsManApplication -Option ReadOnly -Scope Script -Value "wsman"
    Set-Variable -Name CredSSPClientAuthPath -Option ReadOnly -Scope Script -Value "localhost\Client\Auth\CredSSP"
    Set-Variable -Name CredentialsDelegationPolicyPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation"
    Set-Variable -Name AllowFreshCredentialsPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentials"
    Set-Variable -Name AllowFreshCredentialsPropertyName -Option ReadOnly -Scope Script -Value "AllowFreshCredentials"
    Set-Variable -Name TypeAlreadyExistsHResult -Option ReadOnly -Scope Script -Value -2146233088
    Set-Variable -Name NativeCode -Option ReadOnly -Scope Script -Value @"
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    
    namespace SME
    {
        public static class LocalGroupPolicy
        {
            [Guid("EA502722-A23D-11d1-A7D3-0000F87571E3")]
            [ComImport]
            [ClassInterface(ClassInterfaceType.None)]
            public class GPClass
            {
            }
    
            [ComImport, Guid("EA502723-A23D-11d1-A7D3-0000F87571E3"),
            InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
            public interface IGroupPolicyObject
            {
                void New(
                    [MarshalAs(UnmanagedType.LPWStr)] string pszDomainName,
                    [MarshalAs(UnmanagedType.LPWStr)] string pszDisplayName,
                    uint dwFlags);
    
                void OpenDSGPO(
                    [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
                    uint dwFlags);
    
                void OpenLocalMachineGPO(uint dwFlags);
    
                void OpenRemoteMachineGPO(
                    [MarshalAs(UnmanagedType.LPWStr)] string pszComputerName,
                    uint dwFlags);
    
                void Save(
                    [MarshalAs(UnmanagedType.Bool)] bool bMachine,
                    [MarshalAs(UnmanagedType.Bool)] bool bAdd,
                    [MarshalAs(UnmanagedType.LPStruct)] Guid pGuidExtension,
                    [MarshalAs(UnmanagedType.LPStruct)] Guid pGuid);
    
                void Delete();
    
                void GetName(
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName,
                    int cchMaxLength);
    
                void GetDisplayName(
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName,
                    int cchMaxLength);
    
                void SetDisplayName(
                    [MarshalAs(UnmanagedType.LPWStr)] string pszName);
    
                void GetPath(
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath,
                    int cchMaxPath);
    
                void GetDSPath(
                    uint dwSection,
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath,
                    int cchMaxPath);
    
                void GetFileSysPath(
                    uint dwSection,
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszPath,
                    int cchMaxPath);
    
                IntPtr GetRegistryKey(uint dwSection);
    
                uint GetOptions();
    
                void SetOptions(uint dwOptions, uint dwMask);
    
                void GetMachineName(
                    [MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName,
                    int cchMaxLength);
    
                uint GetPropertySheetPages(out IntPtr hPages);
            }
    
            private const int GPO_OPEN_LOAD_REGISTRY = 1;
            private const int GPO_SECTION_MACHINE = 2;
            private const string ApplicationName = @"wsman";
            private const string AllowFreshCredentials = @"AllowFreshCredentials";
            private const string ConcatenateDefaultsAllowFresh = @"ConcatenateDefaults_AllowFresh";
            private const string PathCredentialsDelegationPath = @"SOFTWARE\Policies\Microsoft\Windows";
            private const string GPOpath = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy Objects";
            private const string Machine = @"Machine";
            private const string CredentialsDelegation = @"\CredentialsDelegation";
            private const string PoliciesPath = @"Software\Policies\Microsoft\Windows";
            private const string BackSlash = @"\";
    
            public static string EnableAllowFreshCredentialsPolicy(string[] serverNames)
            {
                if (Thread.CurrentThread.GetApartmentState() == ApartmentState.STA)
                {
                    return EnableAllowFreshCredentialsPolicyImpl(serverNames);
                }
                else
                {
                    string value = null;
    
                    var thread = new Thread(() =>
                    {
                        value = EnableAllowFreshCredentialsPolicyImpl(serverNames);
                    });
    
                    thread.SetApartmentState(ApartmentState.STA);
                    thread.Start();
                    thread.Join();
    
                    return value;
                }
            }
    
            public static string RemoveServersFromAllowFreshCredentialsPolicy(string[] serverNames)
            {
                if (Thread.CurrentThread.GetApartmentState() == ApartmentState.STA)
                {
                    return RemoveServersFromAllowFreshCredentialsPolicyImpl(serverNames);
                }
                else
                {
                    string value = null;
    
                    var thread = new Thread(() =>
                    {
                        value = RemoveServersFromAllowFreshCredentialsPolicyImpl(serverNames);
                    });
    
                    thread.SetApartmentState(ApartmentState.STA);
                    thread.Start();
                    thread.Join();
    
                    return value;
                }
            }
    
            private static string EnableAllowFreshCredentialsPolicyImpl(string[] serverNames)
            {
                IGroupPolicyObject gpo = (IGroupPolicyObject)new GPClass();
                gpo.OpenLocalMachineGPO(GPO_OPEN_LOAD_REGISTRY);
    
                var KeyHandle = gpo.GetRegistryKey(GPO_SECTION_MACHINE);
    
                try
                {
                    var rootKey = Registry.CurrentUser;
    
                    using (RegistryKey GPOKey = rootKey.OpenSubKey(GPOpath, true))
                    {
                        foreach (var keyName in GPOKey.GetSubKeyNames())
                        {
                            if (keyName.EndsWith(Machine, StringComparison.OrdinalIgnoreCase))
                            {
                                var key = GPOpath + BackSlash + keyName + BackSlash + PoliciesPath;
    
                                UpdateGpoRegistrySettingsAllowFreshCredentials(ApplicationName, serverNames, Registry.CurrentUser, key);
                            }
                        }
                    }
    
                    //saving gpo settings
                    gpo.Save(true, true, new Guid("35378EAC-683F-11D2-A89A-00C04FBBCFA2"), new Guid("7A9206BD-33AF-47af-B832-D4128730E990"));
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    KeyHandle = IntPtr.Zero;
                }
    
                return null;
            }
    
            private static string RemoveServersFromAllowFreshCredentialsPolicyImpl(string[] serverNames)
            {
                IGroupPolicyObject gpo = (IGroupPolicyObject)new GPClass();
                gpo.OpenLocalMachineGPO(GPO_OPEN_LOAD_REGISTRY);
    
                var KeyHandle = gpo.GetRegistryKey(GPO_SECTION_MACHINE);
    
                try
                {
                    var rootKey = Registry.CurrentUser;
    
                    using (RegistryKey GPOKey = rootKey.OpenSubKey(GPOpath, true))
                    {
                        foreach (var keyName in GPOKey.GetSubKeyNames())
                        {
                            if (keyName.EndsWith(Machine, StringComparison.OrdinalIgnoreCase))
                            {
                                var key = GPOpath + BackSlash + keyName + BackSlash + PoliciesPath;
    
                                UpdateGpoRegistrySettingsRemoveServersFromFreshCredentials(ApplicationName, serverNames, Registry.CurrentUser, key);
                            }
                        }
                    }
    
                    //saving gpo settings
                    gpo.Save(true, true, new Guid("35378EAC-683F-11D2-A89A-00C04FBBCFA2"), new Guid("7A9206BD-33AF-47af-B832-D4128730E990"));
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    KeyHandle = IntPtr.Zero;
                }
    
                return null;
            }
    
            private static void UpdateGpoRegistrySettingsAllowFreshCredentials(string applicationName, string[] serverNames, RegistryKey rootKey, string registryPath)
            {
                var registryPathCredentialsDelegation = registryPath + CredentialsDelegation;
                var credentialDelegationKey = rootKey.OpenSubKey(registryPathCredentialsDelegation, true);
    
                try
                {
                    if (credentialDelegationKey == null)
                    {
                        credentialDelegationKey = rootKey.CreateSubKey(registryPathCredentialsDelegation, RegistryKeyPermissionCheck.ReadWriteSubTree);
                    }
    
                    credentialDelegationKey.SetValue(AllowFreshCredentials, 1, RegistryValueKind.DWord);
                    credentialDelegationKey.SetValue(ConcatenateDefaultsAllowFresh, 1, RegistryValueKind.DWord);
                }
                finally
                {
                    credentialDelegationKey.Dispose();
                    credentialDelegationKey = null;
                }
    
                var allowFreshCredentialKey = rootKey.OpenSubKey(registryPathCredentialsDelegation + BackSlash + AllowFreshCredentials, true);
    
                try
                {

                    if (allowFreshCredentialKey == null)
                    {
                        allowFreshCredentialKey = rootKey.CreateSubKey(registryPathCredentialsDelegation + BackSlash + AllowFreshCredentials, RegistryKeyPermissionCheck.ReadWriteSubTree);
                    }

                    if (allowFreshCredentialKey != null)
                    {
                        var values = allowFreshCredentialKey.ValueCount;
                        var valuesToAdd = serverNames.ToDictionary(key => string.Format(CultureInfo.InvariantCulture, @"{0}/{1}", applicationName, key), value => value);
                        var valueNames = allowFreshCredentialKey.GetValueNames();
                        var existingValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    
                        foreach (var valueName in valueNames)
                        {
                            var value = allowFreshCredentialKey.GetValue(valueName).ToString();
    
                            if (!existingValues.ContainsKey(value))
                            {
                                existingValues.Add(value, value);
                            }
                        }
    
                        foreach (var key in valuesToAdd.Keys)
                        {
                            if (!existingValues.ContainsKey(key))
                            {
                                allowFreshCredentialKey.SetValue(Convert.ToString(values + 1, CultureInfo.InvariantCulture), key, RegistryValueKind.String);
                                values++;
                            }
                        }
                    }
                }
                finally
                {
                    allowFreshCredentialKey.Dispose();
                    allowFreshCredentialKey = null;
                }
            }
    
            private static void UpdateGpoRegistrySettingsRemoveServersFromFreshCredentials(string applicationName, string[] serverNames, RegistryKey rootKey, string registryPath)
            {
                var registryPathCredentialsDelegation = registryPath + CredentialsDelegation;
    
                using (var allowFreshCredentialKey = rootKey.OpenSubKey(registryPathCredentialsDelegation + BackSlash + AllowFreshCredentials, true))
                {
                    if (allowFreshCredentialKey != null)
                    {
                        var valuesToRemove = serverNames.ToDictionary(key => string.Format(CultureInfo.InvariantCulture, @"{0}/{1}", applicationName, key), value => value);
                        var valueNames = allowFreshCredentialKey.GetValueNames();
    
                        foreach (var valueName in valueNames)
                        {
                            var value = allowFreshCredentialKey.GetValue(valueName).ToString();
                            
                            if (valuesToRemove.ContainsKey(value))
                            {
                                allowFreshCredentialKey.DeleteValue(valueName);
                            }
                        }
                    }
                }
            }
        }
    }
"@  # Cannot have leading whitespace on this line!
}

<#

.SYNOPSIS
Clean up all added global variables, constants, etc.

.DESCRIPTION
Clean up all added global variables, constants, etc.

#>

function cleanupScriptEnv() {
    Remove-Variable -Name WsManApplication -Scope Script -Force
    Remove-Variable -Name CredSSPClientAuthPath -Scope Script -Force
    Remove-Variable -Name CredentialsDelegationPolicyPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPropertyName -Scope Script -Force
    Remove-Variable -Name TypeAlreadyExistsHResult -Scope Script -Force
    Remove-Variable -Name NativeCode -Scope Script -Force
}

<#

.SYNOPSIS
Enable CredSSP client role on this computer.

.DESCRIPTION
Enable the CredSSP client role on this computer.  This computer should be a 
Windows Admin Center gateway, desktop or service mode.

#>

function enableCredSSPClient() {
    $path = "{0}:\{1}" -f $WsManApplication, $CredSSPClientAuthPath

    Set-Item -Path $path True -Force -ErrorAction SilentlyContinue -ErrorVariable +err
}

<#

.SYNOPSIS
Get the CredentialsDelegation container from the registry.

.DESCRIPTION
Get the CredentialsDelegation container from the registry.  If the container
does not exist then a new one will be created.

#>

function getCredentialsDelegationItem() {
    $credentialDelegationItem = Get-Item  $CredentialsDelegationPolicyPath -ErrorAction SilentlyContinue
    if (-not ($credentialDelegationItem)) {
        $credentialDelegationItem = New-Item  $CredentialsDelegationPolicyPath
    }

    return $credentialDelegationItem
}

<#

.SYNOPSIS
Creates the CredentialsDelegation\AllowFreshCredentials container from the registry.

.DESCRIPTION
Create the CredentialsDelegation\AllowFreshCredentials container from the registry.  If the container
does not exist then a new one will be created.

#>

function createAllowFreshCredentialsItem() {
    $allowFreshCredentialsItem = Get-Item $AllowFreshCredentialsPath -ErrorAction SilentlyContinue
    if (-not ($allowFreshCredentialsItem)) {
        New-Item $AllowFreshCredentialsPath
    }
}

<#

.SYNOPSIS
Set the AllowFreshCredentials property value in the CredentialsDelegation container.

.DESCRIPTION
Set the AllowFreshCredentials property value in the CredentialsDelegation container.
If the value exists then it is not changed.

#>

function setAllowFreshCredentialsProperty($credentialDelegationItem) {
    $credentialDelegationItem | New-ItemProperty -Name $AllowFreshCredentialsPropertyName -Value 1 -Type DWord -Force
}

<#

.SYNOPSIS
Add the passed in server(s) to the AllowFreshCredentials key/container.

.DESCRIPTION
Add the passed in server(s) to the AllowFreshCredentials key/container. 
If a given server is already present then do not add it again.

#>

function addServersToAllowFreshCredentials([string[]]$serverNames) {
    $valuesAdded = 0

    foreach ($serverName in $serverNames) {
        $newValue = "{0}/{1}" -f $WsManApplication, $serverName

        # Check if any registry-value nodes values of registry-key node have certain value.
        $key = Get-ChildItem $CredentialsDelegationPolicyPath | ? PSChildName -eq $AllowFreshCredentialsPropertyName
        $hasValue = $false
        $valueNames = $key.GetValueNames()

        foreach ($valueName in $valueNames) {
            $value = $key.GetValue($valueName)

            if ($value -eq $newValue) {
                $hasValue = $true
                break
            }
        }

        if (-not ($hasValue)) {
            New-ItemProperty $AllowFreshCredentialsPath -Name ($valueNames.Length + 1) -Value $newValue -Force
            $valuesAdded++
        }
    }

    return $valuesAdded -gt 0
}

<#

.SYNOPSIS
Add the passed in server(s) to the delegation list in the registry.

.DESCRIPTION
Add the passed in server(s) to the delegation list in the registry.

#>

function addServersToDelegation([string[]] $serverNames) {
    # Default to true because not adding entries is not a failure
    $result = $true

    # Get the CredentialsDelegation key/container
    $credentialDelegationItem = getCredentialsDelegationItem

    # Test, and create if needed, the AllowFreshCredentials property value
    setAllowFreshCredentialsProperty $credentialDelegationItem

    # Create the AllowFreshCredentials key/container
    createAllowFreshCredentialsItem
    
    # Add the servers to the AllowFreshCredentials key/container, if not already present
    $updateGroupPolicy = addServersToAllowFreshCredentials $serverNames

    if ($updateGroupPolicy) {
        $result = setLocalGroupPolicy $serverNames
    }

    return $result
}

<#

.SYNOPSIS
Set the local group policy to match the settings that have already been made.

.DESCRIPTION
Local Group Policy must match the settings that were made by this script to
ensure that an older Local GP setting does not overwrite the thos settings.

#>

function setLocalGroupPolicy([string[]] $serverNames) {
    try {
        Add-Type -TypeDefinition $NativeCode
    } catch {
        if ($_.Exception.HResult -ne $TypeAlreadyExistsHResult) {
            Write-Error $_.Exception.Message

            return $false
        }
    }

    $errorMessage = [SME.LocalGroupPolicy]::EnableAllowFreshCredentialsPolicy($serverNames)

    if ($errorMessage) {
        Write-Error $errorMessage

        return $false
    }

    return $true
}

<#

.SYNOPSIS
Main function of this script.

.DESCRIPTION
Enable CredSSP client role and add the passed in servers to the list
of servers to which this client can delegate credentials.

#>
function main([string[]] $serverNames) {
    setupScriptEnv

    enableCredSSPClient
    $result = addServersToDelegation $serverNames

    cleanupScriptEnv

    return $result
}

###############################################################################
# Script execution starts here
###############################################################################

return main $serverNames

}
## [END] Enable-CredSSPClientRole ##
function Enable-CredSspManagedServer {
<#

.SYNOPSIS
Enables CredSSP on this server.

.DESCRIPTION
Enables CredSSP server role on this server.

.ROLE
Administrators

.LINK
https://portal.msrc.microsoft.com/en-us/security-guidance/advisory/CVE-2018-0886

.LINK
https://aka.ms/CredSSP-Updates


#>

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

function setupScriptEnv() {
    Set-Variable CredSSPServicePath -Option ReadOnly -Scope Script -Value "WSMan:\localhost\Service\Auth\CredSSP"
}

function cleanupScriptEnv() {
    Remove-Variable CredSSPServicePath -Scope Script -Force
}

<#

.SYNOPSIS
Is CredSSP enabled on this server.

.DESCRIPTION
Enables CredSSP on this server for server role.

#>

function getCredSSPServerEnabled()
{
    $credSSPServerEnabled = $false;

    $credSSPServerService = Get-Item $CredSSPServicePath -ErrorAction SilentlyContinue
    if ($credSSPServerService) {
        $credSSPServerEnabled = [System.Convert]::ToBoolean($credSSPServerService.Value)
    }

    return $credSSPServerEnabled
}

<#

.SYNOPSIS
Enables CredSSP on this server.

.DESCRIPTION
Enables CredSSP on this server for server role.

#>

function enableCredSSP() {
    $err = $null

    # Catching the result so that we can discard it. Otherwise it get concatinated with $err and we don't want that!
    $result = Enable-WSManCredSSP -Role Server -Force -ErrorAction SilentlyContinue -ErrorVariable +err

    return $err
}

<#

.SYNOPSIS
Main function.

.DESCRIPTION
Main function.

#>

function main() {
    setupScriptEnv

    $retVal = $true
    
    # If server role is enabled then return success.
    if (-not (getCredSSPServerEnabled)) {
        # If not enabled try to enable
        $err = enableCredSSP
        if ($err) {
            # If there was an error, and server role is not enabled return error.
            if (-not (getCredSSPServerEnabled)) {
                $retVal = $false
                
                Write-Error $err
            }
        }
    }

    cleanupScriptEnv

    return $retVal
}

###############################################################################
# Script execution starts here...
###############################################################################

return main

}
## [END] Enable-CredSspManagedServer ##
function Get-CimWin32LogicalDisk {
<#

.SYNOPSIS
Gets Win32_LogicalDisk object.

.DESCRIPTION
Gets Win32_LogicalDisk object.

.ROLE
Readers

#>
##SkipCheck=true##


import-module CimCmdlets

Get-CimInstance -Namespace root/cimv2 -ClassName Win32_LogicalDisk

}
## [END] Get-CimWin32LogicalDisk ##
function Get-CimWin32NetworkAdapter {
<#

.SYNOPSIS
Gets Win32_NetworkAdapter object.

.DESCRIPTION
Gets Win32_NetworkAdapter object.

.ROLE
Readers

#>
##SkipCheck=true##


import-module CimCmdlets

Get-CimInstance -Namespace root/cimv2 -ClassName Win32_NetworkAdapter

}
## [END] Get-CimWin32NetworkAdapter ##
function Get-CimWin32OperatingSystem {
<#

.SYNOPSIS
Gets Win32_OperatingSystem object.

.DESCRIPTION
Gets Win32_OperatingSystem object.

.ROLE
Readers

#>
##SkipCheck=true##


import-module CimCmdlets

Get-CimInstance -Namespace root/cimv2 -ClassName Win32_OperatingSystem

}
## [END] Get-CimWin32OperatingSystem ##
function Get-CimWin32PhysicalMemory {
<#

.SYNOPSIS
Gets Win32_PhysicalMemory object.

.DESCRIPTION
Gets Win32_PhysicalMemory object.

.ROLE
Readers

#>
##SkipCheck=true##


import-module CimCmdlets

Get-CimInstance -Namespace root/cimv2 -ClassName Win32_PhysicalMemory

}
## [END] Get-CimWin32PhysicalMemory ##
function Get-CimWin32Processor {
<#

.SYNOPSIS
Gets Win32_Processor object.

.DESCRIPTION
Gets Win32_Processor object.

.ROLE
Readers

#>
##SkipCheck=true##


import-module CimCmdlets

Get-CimInstance -Namespace root/cimv2 -ClassName Win32_Processor

}
## [END] Get-CimWin32Processor ##
function Get-ClusterInventory {
<#

.SYNOPSIS
Retrieves the inventory data for a cluster.

.DESCRIPTION
Retrieves the inventory data for a cluster.

.ROLE
Readers

#>

import-module CimCmdlets -ErrorAction SilentlyContinue

# JEA code requires to pre-import the module (this is slow on failover cluster environment.)
import-module FailoverClusters -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Get the name of this computer.

.DESCRIPTION
Get the best available name for this computer.  The FQDN is preferred, but when not avaialble
the NetBIOS name will be used instead.

#>

function getComputerName() {
    $computerSystem = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue | Microsoft.PowerShell.Utility\Select-Object Name, DNSHostName

    if ($computerSystem) {
        $computerName = $computerSystem.DNSHostName

        if ($null -eq $computerName) {
            $computerName = $computerSystem.Name
        }

        return $computerName
    }

    return $null
}

<#

.SYNOPSIS
Are the cluster PowerShell cmdlets installed on this server?

.DESCRIPTION
Are the cluster PowerShell cmdlets installed on this server?

#>

function getIsClusterCmdletAvailable() {
    $cmdlet = Get-Command "Get-Cluster" -ErrorAction SilentlyContinue

    return !!$cmdlet
}

<#

.SYNOPSIS
Get the MSCluster Cluster CIM instance from this server.

.DESCRIPTION
Get the MSCluster Cluster CIM instance from this server.

#>
function getClusterCimInstance() {
    $namespace = Get-CimInstance -Namespace root/MSCluster -ClassName __NAMESPACE -ErrorAction SilentlyContinue

    if ($namespace) {
        return Get-CimInstance -Namespace root/mscluster MSCluster_Cluster -ErrorAction SilentlyContinue | Microsoft.PowerShell.Utility\Select-Object fqdn, S2DEnabled
    }

    return $null
}


<#

.SYNOPSIS
Determines if the current cluster supports Failover Clusters Time Series Database.

.DESCRIPTION
Use the existance of the path value of cmdlet Get-StorageHealthSetting to determine if TSDB 
is supported or not.

#>
function getClusterPerformanceHistoryPath() {
    return $null -ne (Get-StorageSubSystem clus* | Get-StorageHealthSetting -Name "System.PerformanceHistory.Path")
}

<#

.SYNOPSIS
Get some basic information about the cluster from the cluster.

.DESCRIPTION
Get the needed cluster properties from the cluster.

#>
function getClusterInfo() {
    $returnValues = @{}

    $returnValues.Fqdn = $null
    $returnValues.isS2DEnabled = $false
    $returnValues.isTsdbEnabled = $false

    $cluster = getClusterCimInstance
    if ($cluster) {
        $returnValues.Fqdn = $cluster.fqdn
        $isS2dEnabled = !!(Get-Member -InputObject $cluster -Name "S2DEnabled") -and ($cluster.S2DEnabled -eq 1)
        $returnValues.isS2DEnabled = $isS2dEnabled

        if ($isS2DEnabled) {
            $returnValues.isTsdbEnabled = getClusterPerformanceHistoryPath
        } else {
            $returnValues.isTsdbEnabled = $false
        }
    }

    return $returnValues
}

<#

.SYNOPSIS
Are the cluster PowerShell Health cmdlets installed on this server?

.DESCRIPTION
Are the cluster PowerShell Health cmdlets installed on this server?

s#>
function getisClusterHealthCmdletAvailable() {
    $cmdlet = Get-Command -Name "Get-HealthFault" -ErrorAction SilentlyContinue

    return !!$cmdlet
}
<#

.SYNOPSIS
Are the Britannica (sddc management resources) available on the cluster?

.DESCRIPTION
Are the Britannica (sddc management resources) available on the cluster?

#>
function getIsBritannicaEnabled() {
    return $null -ne (Get-CimInstance -Namespace root/sddc/management -ClassName SDDC_Cluster -ErrorAction SilentlyContinue)
}

<#

.SYNOPSIS
Are the Britannica (sddc management resources) virtual machine available on the cluster?

.DESCRIPTION
Are the Britannica (sddc management resources) virtual machine available on the cluster?

#>
function getIsBritannicaVirtualMachineEnabled() {
    return $null -ne (Get-CimInstance -Namespace root/sddc/management -ClassName SDDC_VirtualMachine -ErrorAction SilentlyContinue)
}

<#

.SYNOPSIS
Are the Britannica (sddc management resources) virtual switch available on the cluster?

.DESCRIPTION
Are the Britannica (sddc management resources) virtual switch available on the cluster?

#>
function getIsBritannicaVirtualSwitchEnabled() {
    return $null -ne (Get-CimInstance -Namespace root/sddc/management -ClassName SDDC_VirtualSwitch -ErrorAction SilentlyContinue)
}

###########################################################################
# main()
###########################################################################

$clusterInfo = getClusterInfo

$result = New-Object PSObject

$result | Add-Member -MemberType NoteProperty -Name 'Fqdn' -Value $clusterInfo.Fqdn
$result | Add-Member -MemberType NoteProperty -Name 'IsS2DEnabled' -Value $clusterInfo.isS2DEnabled
$result | Add-Member -MemberType NoteProperty -Name 'IsTsdbEnabled' -Value $clusterInfo.isTsdbEnabled
$result | Add-Member -MemberType NoteProperty -Name 'IsClusterHealthCmdletAvailable' -Value (getIsClusterHealthCmdletAvailable)
$result | Add-Member -MemberType NoteProperty -Name 'IsBritannicaEnabled' -Value (getIsBritannicaEnabled)
$result | Add-Member -MemberType NoteProperty -Name 'IsBritannicaVirtualMachineEnabled' -Value (getIsBritannicaVirtualMachineEnabled)
$result | Add-Member -MemberType NoteProperty -Name 'IsBritannicaVirtualSwitchEnabled' -Value (getIsBritannicaVirtualSwitchEnabled)
$result | Add-Member -MemberType NoteProperty -Name 'IsClusterCmdletAvailable' -Value (getIsClusterCmdletAvailable)
$result | Add-Member -MemberType NoteProperty -Name 'CurrentClusterNode' -Value (getComputerName)

$result

}
## [END] Get-ClusterInventory ##
function Get-ClusterNodes {
<#

.SYNOPSIS
Retrieves the inventory data for cluster nodes in a particular cluster.

.DESCRIPTION
Retrieves the inventory data for cluster nodes in a particular cluster.

.ROLE
Readers

#>

import-module CimCmdlets

# JEA code requires to pre-import the module (this is slow on failover cluster environment.)
import-module FailoverClusters -ErrorAction SilentlyContinue

###############################################################################
# Constants
###############################################################################

Set-Variable -Name LogName -Option Constant -Value "Microsoft-ServerManagementExperience" -ErrorAction SilentlyContinue
Set-Variable -Name LogSource -Option Constant -Value "SMEScripts" -ErrorAction SilentlyContinue
Set-Variable -Name ScriptName -Option Constant -Value $MyInvocation.ScriptName -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Are the cluster PowerShell cmdlets installed?

.DESCRIPTION
Use the Get-Command cmdlet to quickly test if the cluster PowerShell cmdlets
are installed on this server.

#>

function getClusterPowerShellSupport() {
    $cmdletInfo = Get-Command 'Get-ClusterNode' -ErrorAction SilentlyContinue

    return $cmdletInfo -and $cmdletInfo.Name -eq "Get-ClusterNode"
}

<#

.SYNOPSIS
Get the cluster nodes using the cluster CIM provider.

.DESCRIPTION
When the cluster PowerShell cmdlets are not available fallback to using
the cluster CIM provider to get the needed information.

#>

function getClusterNodeCimInstances() {
    # Change the WMI property NodeDrainStatus to DrainStatus to match the PS cmdlet output.
    return Get-CimInstance -Namespace root/mscluster MSCluster_Node -ErrorAction SilentlyContinue | `
        Microsoft.PowerShell.Utility\Select-Object @{Name="DrainStatus"; Expression={$_.NodeDrainStatus}}, DynamicWeight, Name, NodeWeight, FaultDomain, State
}

<#

.SYNOPSIS
Get the cluster nodes using the cluster PowerShell cmdlets.

.DESCRIPTION
When the cluster PowerShell cmdlets are available use this preferred function.

#>

function getClusterNodePsInstances() {
    return Get-ClusterNode -ErrorAction SilentlyContinue | Microsoft.PowerShell.Utility\Select-Object DrainStatus, DynamicWeight, Name, NodeWeight, FaultDomain, State
}

<#

.SYNOPSIS
Use DNS services to get the FQDN of the cluster NetBIOS name.

.DESCRIPTION
Use DNS services to get the FQDN of the cluster NetBIOS name.

.Notes
It is encouraged that the caller add their approprate -ErrorAction when
calling this function.

#>

function getClusterNodeFqdn([string]$clusterNodeName) {
    return ([System.Net.Dns]::GetHostEntry($clusterNodeName)).HostName
}

<#

.SYNOPSIS
Writes message to event log as warning.

.DESCRIPTION
Writes message to event log as warning.

#>

function writeToEventLog([string]$message) {
    Microsoft.PowerShell.Management\New-EventLog -LogName $LogName -Source $LogSource -ErrorAction SilentlyContinue
    Microsoft.PowerShell.Management\Write-EventLog -LogName $LogName -Source $LogSource -EventId 0 -Category 0 -EntryType Warning `
        -Message $message  -ErrorAction SilentlyContinue
}

<#

.SYNOPSIS
Get the cluster nodes.

.DESCRIPTION
When the cluster PowerShell cmdlets are available get the information about the cluster nodes
using PowerShell.  When the cmdlets are not available use the Cluster CIM provider.

#>

function getClusterNodes() {
    $isClusterCmdletAvailable = getClusterPowerShellSupport

    if ($isClusterCmdletAvailable) {
        $clusterNodes = getClusterNodePsInstances
    } else {
        $clusterNodes = getClusterNodeCimInstances
    }

    $clusterNodeMap = @{}

    foreach ($clusterNode in $clusterNodes) {
        $clusterNodeName = $clusterNode.Name.ToLower()
        try 
        {
            $clusterNodeFqdn = getClusterNodeFqdn $clusterNodeName -ErrorAction SilentlyContinue
        }
        catch 
        {
            $clusterNodeFqdn = $clusterNodeName
            writeToEventLog "[$ScriptName]: The fqdn for node '$clusterNodeName' could not be obtained. Defaulting to machine name '$clusterNodeName'"
        }

        $clusterNodeResult = New-Object PSObject

        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'FullyQualifiedDomainName' -Value $clusterNodeFqdn
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'Name' -Value $clusterNodeName
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'DynamicWeight' -Value $clusterNode.DynamicWeight
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'NodeWeight' -Value $clusterNode.NodeWeight
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'FaultDomain' -Value $clusterNode.FaultDomain
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'State' -Value $clusterNode.State
        $clusterNodeResult | Add-Member -MemberType NoteProperty -Name 'DrainStatus' -Value $clusterNode.DrainStatus

        $clusterNodeMap.Add($clusterNodeName, $clusterNodeResult)
    }

    return $clusterNodeMap
}

###########################################################################
# main()
###########################################################################

getClusterNodes

}
## [END] Get-ClusterNodes ##
function Get-CredSspClientRole {
<#

.SYNOPSIS
Gets the CredSSP enabled state on this computer as client role to the other computer.

.DESCRIPTION
Gets the CredSSP enabled state on this computer as client role to the other computer.

.ROLE
Administrators

.PARAMETER serverNames
The names of the server to which this gateway can forward credentials.

.LINK
https://portal.msrc.microsoft.com/en-us/security-guidance/advisory/CVE-2018-0886

.LINK
https://aka.ms/CredSSP-Updates

#>

param (
    [Parameter(Mandatory=$True)]
    [string[]]$serverNames
)

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Setup all necessary global variables, constants, etc.

.DESCRIPTION
Setup all necessary global variables, constants, etc.

#>

function setupScriptEnv() {
    Set-Variable -Name WsManApplication -Option ReadOnly -Scope Script -Value "wsman"
    Set-Variable -Name CredSSPClientAuthPath -Option ReadOnly -Scope Script -Value "localhost\Client\Auth\CredSSP"
    Set-Variable -Name CredentialsDelegationPolicyPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation"
    Set-Variable -Name AllowFreshCredentialsPath -Option ReadOnly -Scope Script -Value "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CredentialsDelegation\AllowFreshCredentials"
    Set-Variable -Name AllowFreshCredentialsPropertyName -Option ReadOnly -Scope Script -Value "AllowFreshCredentials"
}

<#

.SYNOPSIS
Clean up all added global variables, constants, etc.

.DESCRIPTION
Clean up all added global variables, constants, etc.

#>

function cleanupScriptEnv() {
    Remove-Variable -Name WsManApplication -Scope Script -Force
    Remove-Variable -Name CredSSPClientAuthPath -Scope Script -Force
    Remove-Variable -Name CredentialsDelegationPolicyPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPath -Scope Script -Force
    Remove-Variable -Name AllowFreshCredentialsPropertyName -Scope Script -Force
}

<#

.SYNOPSIS
Is CredSSP client role enabled on this server.

.DESCRIPTION
When the CredSSP client role is enabled on this server then return $true.

#>

function getCredSSPClientEnabled() {
    $path = "{0}:\{1}" -f $WsManApplication, $CredSSPClientAuthPath

    $credSSPClientEnabled = $false;

    $credSSPClientService = Get-Item $path -ErrorAction SilentlyContinue
    if ($credSSPClientService) {
        $credSSPClientEnabled = [System.Convert]::ToBoolean($credSSPClientService.Value)
    }

    return $credSSPClientEnabled
}

<#

.SYNOPSIS
Are the servers already configure to delegate fresh credentials?

.DESCRIPTION
Are the servers already configure to delegate fresh credentials?

#>

function getServersDelegated([string[]] $serverNames) {
    $valuesFound = 0

    foreach ($serverName in $serverNames) {
        $newValue = "{0}/{1}" -f $WsManApplication, $serverName

        # Check if any registry-value nodes values of registry-key node have certain value.
        $key = Get-ChildItem $CredentialsDelegationPolicyPath | ? PSChildName -eq $AllowFreshCredentialsPropertyName
        $valueNames = $key.GetValueNames()

        foreach ($valueName in $valueNames) {
            $value = $key.GetValue($valueName)

            if ($value -eq $newValue) {
                $valuesFound++
                break
            }
        }
    }

    return $valuesFound -eq $serverNames.Length
}

<#

.SYNOPSIS
Detemines if the required CredentialsDelegation containers are in the registry.

.DESCRIPTION
Get the CredentialsDelegation container from the registry.  If the container
does not exist then we can return false since CredSSP is not configured on this
client (gateway).

#>

function areCredentialsDelegationItemsPresent() {
    $credentialDelegationItem = Get-Item  $CredentialsDelegationPolicyPath -ErrorAction SilentlyContinue
    if ($credentialDelegationItem) {
        $key = Get-ChildItem $CredentialsDelegationPolicyPath | ? PSChildName -eq $AllowFreshCredentialsPropertyName

        if ($key) {
            $valueNames = $key.GetValueNames()
            if ($valueNames) {
                return $true
            }
        }
    }

    return $false
}

<#

.SYNOPSIS
Main function of this script.

.DESCRIPTION
Return true if the gateway is already configured as a CredSSP client, and all of the servers provided
have already been configured to allow fresh credential delegation.

#>

function main([string[]] $serverNames) {
    setupScriptEnv

    $serversDelegated = $false

    $clientEnabled = getCredSSPClientEnabled
    
    if (areCredentialsDelegationItemsPresent) {
        $serversDelegated = getServersDelegated $serverNames
    }

    cleanupScriptEnv

    return $clientEnabled -and $serversDelegated
}

###############################################################################
# Script execution starts here
###############################################################################

return main $serverNames

}
## [END] Get-CredSspClientRole ##
function Get-CredSspManagedServer {
<#

.SYNOPSIS
Gets the CredSSP server role on this server.

.DESCRIPTION
Gets the CredSSP server role on this server.

.ROLE
Administrators

.Notes
The feature(s) that use this script are still in development and should be considered as being "In Preview".
Therefore, those feature(s) and/or this script may change at any time.

#>

Set-StrictMode -Version 5.0
Import-Module  Microsoft.WSMan.Management -ErrorAction SilentlyContinue

<#

.SYNOPSIS
Setup all necessary global variables, constants, etc.

.DESCRIPTION
Setup all necessary global variables, constants, etc.

#>

function setupScriptEnv() {
    Set-Variable -Name WsManApplication -Option ReadOnly -Scope Script -Value "wsman"
    Set-Variable -Name CredSSPServiceAuthPath -Option ReadOnly -Scope Script -Value "localhost\Service\Auth\CredSSP"
}

<#

.SYNOPSIS
Clean up all added global variables, constants, etc.

.DESCRIPTION
Clean up all added global variables, constants, etc.

#>

function cleanupScriptEnv() {
    Remove-Variable -Name WsManApplication -Scope Script -Force
    Remove-Variable -Name CredSSPServiceAuthPath -Scope Script -Force
}

<#

.SYNOPSIS
Is CredSSP server role enabled on this server.

.DESCRIPTION
When the CredSSP server role is enabled on this server then return $true.

#>

function getCredSSPServerEnabled() {
    $path = "{0}:\{1}" -f $WsManApplication, $CredSSPServiceAuthPath

    $credSSPServerEnabled = $false;

    $credSSPServerService = Get-Item $path -ErrorAction SilentlyContinue
    if ($credSSPServerService) {
        $credSSPServerEnabled = [System.Convert]::ToBoolean($credSSPServerService.Value)
    }

    return $credSSPServerEnabled
}

<#

.SYNOPSIS
Main function.

.DESCRIPTION
Main function.

#>

function main() {
    setupScriptEnv

    $result = getCredSSPServerEnabled

    cleanupScriptEnv

    return $result
}

###############################################################################
# Script execution starts here...
###############################################################################

if (-not ($env:pester)) {
    return main
}

}
## [END] Get-CredSspManagedServer ##
function Get-ScheduledTask {
<#

.SYNOPSIS
Gets details of scheduled task.
.DESCRIPTION

.ROLE
Administrators

#>


Get-ScheduledTaskInfo -TaskName WACInstallUpdates

}
## [END] Get-ScheduledTask ##
function Get-ServerInventory {
<#

.SYNOPSIS
Retrieves the inventory data for a server.

.DESCRIPTION
Retrieves the inventory data for a server.

.ROLE
Readers

#>

Set-StrictMode -Version 5.0

Import-Module CimCmdlets

<#

.SYNOPSIS
Converts an arbitrary version string into just 'Major.Minor'

.DESCRIPTION
To make OS version comparisons we only want to compare the major and
minor version.  Build number and/os CSD are not interesting.

#>

function convertOsVersion([string]$osVersion) {
  [Ref]$parsedVersion = $null
  if (![Version]::TryParse($osVersion, $parsedVersion)) {
    return $null
  }

  $version = [Version]$parsedVersion.Value
  return New-Object Version -ArgumentList $version.Major, $version.Minor
}

<#

.SYNOPSIS
Determines if CredSSP is enabled for the current server or client.

.DESCRIPTION
Check the registry value for the CredSSP enabled state.

#>

function isCredSSPEnabled() {
  Set-Variable credSSPServicePath -Option Constant -Value "WSMan:\localhost\Service\Auth\CredSSP"
  Set-Variable credSSPClientPath -Option Constant -Value "WSMan:\localhost\Client\Auth\CredSSP"

  $credSSPServerEnabled = $false;
  $credSSPClientEnabled = $false;

  $credSSPServerService = Get-Item $credSSPServicePath -ErrorAction SilentlyContinue
  if ($credSSPServerService) {
    $credSSPServerEnabled = [System.Convert]::ToBoolean($credSSPServerService.Value)
  }

  $credSSPClientService = Get-Item $credSSPClientPath -ErrorAction SilentlyContinue
  if ($credSSPClientService) {
    $credSSPClientEnabled = [System.Convert]::ToBoolean($credSSPClientService.Value)
  }

  return ($credSSPServerEnabled -or $credSSPClientEnabled)
}

<#

.SYNOPSIS
Determines if the Hyper-V role is installed for the current server or client.

.DESCRIPTION
The Hyper-V role is installed when the VMMS service is available.  This is much
faster then checking Get-WindowsFeature and works on Windows Client SKUs.

#>

function isHyperVRoleInstalled() {
  $vmmsService = Get-Service -Name "VMMS" -ErrorAction SilentlyContinue

  return $vmmsService -and $vmmsService.Name -eq "VMMS"
}

<#

.SYNOPSIS
Determines if the Hyper-V PowerShell support module is installed for the current server or client.

.DESCRIPTION
The Hyper-V PowerShell support module is installed when the modules cmdlets are available.  This is much
faster then checking Get-WindowsFeature and works on Windows Client SKUs.

#>
function isHyperVPowerShellSupportInstalled() {
  # quicker way to find the module existence. it doesn't load the module.
  return !!(Get-Module -ListAvailable Hyper-V -ErrorAction SilentlyContinue)
}

<#

.SYNOPSIS
Determines if Windows Management Framework (WMF) 5.0, or higher, is installed for the current server or client.

.DESCRIPTION
Windows Admin Center requires WMF 5 so check the registey for WMF version on Windows versions that are less than
Windows Server 2016.

#>
function isWMF5Installed([string] $operatingSystemVersion) {
  Set-Variable Server2016 -Option Constant -Value (New-Object Version '10.0')   # And Windows 10 client SKUs
  Set-Variable Server2012 -Option Constant -Value (New-Object Version '6.2')

  $version = convertOsVersion $operatingSystemVersion
  if (-not $version) {
    # Since the OS version string is not properly formatted we cannot know the true installed state.
    return $false
  }

  if ($version -ge $Server2016) {
    # It's okay to assume that 2016 and up comes with WMF 5 or higher installed
    return $true
  }
  else {
    if ($version -ge $Server2012) {
      # Windows 2012/2012R2 are supported as long as WMF 5 or higher is installed
      $registryKey = 'HKLM:\SOFTWARE\Microsoft\PowerShell\3\PowerShellEngine'
      $registryKeyValue = Get-ItemProperty -Path $registryKey -Name PowerShellVersion -ErrorAction SilentlyContinue

      if ($registryKeyValue -and ($registryKeyValue.PowerShellVersion.Length -ne 0)) {
        $installedWmfVersion = [Version]$registryKeyValue.PowerShellVersion

        if ($installedWmfVersion -ge [Version]'5.0') {
          return $true
        }
      }
    }
  }

  return $false
}

<#

.SYNOPSIS
Determines if the current usser is a system administrator of the current server or client.

.DESCRIPTION
Determines if the current usser is a system administrator of the current server or client.

#>
function isUserAnAdministrator() {
  return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

<#

.SYNOPSIS
Get some basic information about the Failover Cluster that is running on this server.

.DESCRIPTION
Create a basic inventory of the Failover Cluster that may be running in this server.

#>
function getClusterInformation() {
  $returnValues = @{ }

  $returnValues.IsS2dEnabled = $false
  $returnValues.IsCluster = $false
  $returnValues.ClusterFqdn = $null
  $returnValues.IsBritannicaEnabled = $false

  $namespace = Get-CimInstance -Namespace root/MSCluster -ClassName __NAMESPACE -ErrorAction SilentlyContinue
  if ($namespace) {
    $cluster = Get-CimInstance -Namespace root/MSCluster -ClassName MSCluster_Cluster -ErrorAction SilentlyContinue
    if ($cluster) {
      $returnValues.IsCluster = $true
      $returnValues.ClusterFqdn = $cluster.Fqdn
      $returnValues.IsS2dEnabled = !!(Get-Member -InputObject $cluster -Name "S2DEnabled") -and ($cluster.S2DEnabled -gt 0)
      $returnValues.IsBritannicaEnabled = $null -ne (Get-CimInstance -Namespace root/sddc/management -ClassName SDDC_Cluster -ErrorAction SilentlyContinue)
    }
  }

  return $returnValues
}

<#

.SYNOPSIS
Get the Fully Qaulified Domain (DNS domain) Name (FQDN) of the passed in computer name.

.DESCRIPTION
Get the Fully Qaulified Domain (DNS domain) Name (FQDN) of the passed in computer name.

#>
function getComputerFqdnAndAddress($computerName) {
  $hostEntry = [System.Net.Dns]::GetHostEntry($computerName)
  $addressList = @()
  foreach ($item in $hostEntry.AddressList) {
    $address = New-Object PSObject
    $address | Add-Member -MemberType NoteProperty -Name 'IpAddress' -Value $item.ToString()
    $address | Add-Member -MemberType NoteProperty -Name 'AddressFamily' -Value $item.AddressFamily.ToString()
    $addressList += $address
  }

  $result = New-Object PSObject
  $result | Add-Member -MemberType NoteProperty -Name 'Fqdn' -Value $hostEntry.HostName
  $result | Add-Member -MemberType NoteProperty -Name 'AddressList' -Value $addressList
  return $result
}

<#

.SYNOPSIS
Get the Fully Qaulified Domain (DNS domain) Name (FQDN) of the current server or client.

.DESCRIPTION
Get the Fully Qaulified Domain (DNS domain) Name (FQDN) of the current server or client.

#>
function getHostFqdnAndAddress($computerSystem) {
  $computerName = $computerSystem.DNSHostName
  if (!$computerName) {
    $computerName = $computerSystem.Name
  }

  return getComputerFqdnAndAddress $computerName
}

<#

.SYNOPSIS
Are the needed management CIM interfaces available on the current server or client.

.DESCRIPTION
Check for the presence of the required server management CIM interfaces.

#>
function getManagementToolsSupportInformation() {
  $returnValues = @{ }

  $returnValues.ManagementToolsAvailable = $false
  $returnValues.ServerManagerAvailable = $false

  $namespaces = Get-CimInstance -Namespace root/microsoft/windows -ClassName __NAMESPACE -ErrorAction SilentlyContinue

  if ($namespaces) {
    $returnValues.ManagementToolsAvailable = !!($namespaces | Where-Object { $_.Name -ieq "ManagementTools" })
    $returnValues.ServerManagerAvailable = !!($namespaces | Where-Object { $_.Name -ieq "ServerManager" })
  }

  return $returnValues
}

<#

.SYNOPSIS
Check the remote app enabled or not.

.DESCRIPTION
Check the remote app enabled or not.

#>
function isRemoteAppEnabled() {
  Set-Variable key -Option Constant -Value "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Terminal Server\\TSAppAllowList"

  $registryKeyValue = Get-ItemProperty -Path $key -Name fDisabledAllowList -ErrorAction SilentlyContinue

  if (-not $registryKeyValue) {
    return $false
  }
  return $registryKeyValue.fDisabledAllowList -eq 1
}

<#

.SYNOPSIS
Check the remote app enabled or not.

.DESCRIPTION
Check the remote app enabled or not.

#>

<#
c
.SYNOPSIS
Get the Win32_OperatingSystem information

.DESCRIPTION
Get the Win32_OperatingSystem instance and filter the results to just the required properties.
This filtering will make the response payload much smaller.

#>
function getOperatingSystemInfo() {
  return Get-CimInstance Win32_OperatingSystem | Microsoft.PowerShell.Utility\Select-Object csName, Caption, OperatingSystemSKU, Version, ProductType, OSType, LastBootUpTime
}

<#

.SYNOPSIS
Get the Win32_ComputerSystem information

.DESCRIPTION
Get the Win32_ComputerSystem instance and filter the results to just the required properties.
This filtering will make the response payload much smaller.

#>
function getComputerSystemInfo() {
  return Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue | `
    Microsoft.PowerShell.Utility\Select-Object TotalPhysicalMemory, DomainRole, Manufacturer, Model, NumberOfLogicalProcessors, Domain, Workgroup, DNSHostName, Name, PartOfDomain, SystemFamily, SystemSKUNumber
}

<#

.SYNOPSIS
script to query SMBIOS locally from the passed in machineName


.DESCRIPTION
script to query SMBIOS locally from the passed in machine name
#>
function getSmbiosData($computerSystem) {
  <#
    Array of chassis types.
    The following list of ChassisTypes is copied from the latest DMTF SMBIOS specification.
    REF: https://www.dmtf.org/sites/default/files/standards/documents/DSP0134_3.1.1.pdf
  #>
  $ChassisTypes =
  @{
    1  = 'Other'
    2  = 'Unknown'
    3  = 'Desktop'
    4  = 'Low Profile Desktop'
    5  = 'Pizza Box'
    6  = 'Mini Tower'
    7  = 'Tower'
    8  = 'Portable'
    9  = 'Laptop'
    10 = 'Notebook'
    11 = 'Hand Held'
    12 = 'Docking Station'
    13 = 'All in One'
    14 = 'Sub Notebook'
    15 = 'Space-Saving'
    16 = 'Lunch Box'
    17 = 'Main System Chassis'
    18 = 'Expansion Chassis'
    19 = 'SubChassis'
    20 = 'Bus Expansion Chassis'
    21 = 'Peripheral Chassis'
    22 = 'Storage Chassis'
    23 = 'Rack Mount Chassis'
    24 = 'Sealed-Case PC'
    25 = 'Multi-system chassis'
    26 = 'Compact PCI'
    27 = 'Advanced TCA'
    28 = 'Blade'
    29 = 'Blade Enclosure'
    30 = 'Tablet'
    31 = 'Convertible'
    32 = 'Detachable'
    33 = 'IoT Gateway'
    34 = 'Embedded PC'
    35 = 'Mini PC'
    36 = 'Stick PC'
  }

  $list = New-Object System.Collections.ArrayList
  $win32_Bios = Get-CimInstance -class Win32_Bios
  $obj = New-Object -Type PSObject | Microsoft.PowerShell.Utility\Select-Object SerialNumber, Manufacturer, UUID, BaseBoardProduct, ChassisTypes, Chassis, SystemFamily, SystemSKUNumber, SMBIOSAssetTag
  $obj.SerialNumber = $win32_Bios.SerialNumber
  $obj.Manufacturer = $win32_Bios.Manufacturer
  $computerSystemProduct = Get-CimInstance Win32_ComputerSystemProduct
  if ($null -ne $computerSystemProduct) {
    $obj.UUID = $computerSystemProduct.UUID
  }
  $baseboard = Get-CimInstance Win32_BaseBoard
  if ($null -ne $baseboard) {
    $obj.BaseBoardProduct = $baseboard.Product
  }
  $systemEnclosure = Get-CimInstance Win32_SystemEnclosure
  if ($null -ne $systemEnclosure) {
    $obj.SMBIOSAssetTag = $systemEnclosure.SMBIOSAssetTag
  }
  $obj.ChassisTypes = Get-CimInstance Win32_SystemEnclosure | Microsoft.PowerShell.Utility\Select-Object -ExpandProperty ChassisTypes
  $obj.Chassis = New-Object -TypeName 'System.Collections.ArrayList'
  $obj.ChassisTypes | ForEach-Object -Process {
    $obj.Chassis.Add($ChassisTypes[[int]$_])
  }
  $obj.SystemFamily = $computerSystem.SystemFamily
  $obj.SystemSKUNumber = $computerSystem.SystemSKUNumber
  $list.Add($obj) | Out-Null

  return $list

}
###########################################################################
# main()
###########################################################################

$operatingSystem = getOperatingSystemInfo
$computerSystem = getComputerSystemInfo
$isAdministrator = isUserAnAdministrator
$fqdnAndAddress = getHostFqdnAndAddress $computerSystem
$hostname = [Environment]::MachineName
$netbios = $env:ComputerName
$managementToolsInformation = getManagementToolsSupportInformation
$isWmfInstalled = isWMF5Installed $operatingSystem.Version
$clusterInformation = getClusterInformation -ErrorAction SilentlyContinue
$isHyperVPowershellInstalled = isHyperVPowerShellSupportInstalled
$isHyperVRoleInstalled = isHyperVRoleInstalled
$isCredSSPEnabled = isCredSSPEnabled
$isRemoteAppEnabled = isRemoteAppEnabled
$smbiosData = getSmbiosData $computerSystem

$result = New-Object PSObject
$result | Add-Member -MemberType NoteProperty -Name 'IsAdministrator' -Value $isAdministrator
$result | Add-Member -MemberType NoteProperty -Name 'OperatingSystem' -Value $operatingSystem
$result | Add-Member -MemberType NoteProperty -Name 'ComputerSystem' -Value $computerSystem
$result | Add-Member -MemberType NoteProperty -Name 'Fqdn' -Value $fqdnAndAddress.Fqdn
$result | Add-Member -MemberType NoteProperty -Name 'AddressList' -Value $fqdnAndAddress.AddressList
$result | Add-Member -MemberType NoteProperty -Name 'Hostname' -Value $hostname
$result | Add-Member -MemberType NoteProperty -Name 'NetBios' -Value $netbios
$result | Add-Member -MemberType NoteProperty -Name 'IsManagementToolsAvailable' -Value $managementToolsInformation.ManagementToolsAvailable
$result | Add-Member -MemberType NoteProperty -Name 'IsServerManagerAvailable' -Value $managementToolsInformation.ServerManagerAvailable
$result | Add-Member -MemberType NoteProperty -Name 'IsWmfInstalled' -Value $isWmfInstalled
$result | Add-Member -MemberType NoteProperty -Name 'IsCluster' -Value $clusterInformation.IsCluster
$result | Add-Member -MemberType NoteProperty -Name 'ClusterFqdn' -Value $clusterInformation.ClusterFqdn
$result | Add-Member -MemberType NoteProperty -Name 'IsS2dEnabled' -Value $clusterInformation.IsS2dEnabled
$result | Add-Member -MemberType NoteProperty -Name 'IsBritannicaEnabled' -Value $clusterInformation.IsBritannicaEnabled
$result | Add-Member -MemberType NoteProperty -Name 'IsHyperVRoleInstalled' -Value $isHyperVRoleInstalled
$result | Add-Member -MemberType NoteProperty -Name 'IsHyperVPowershellInstalled' -Value $isHyperVPowershellInstalled
$result | Add-Member -MemberType NoteProperty -Name 'IsCredSSPEnabled' -Value $isCredSSPEnabled
$result | Add-Member -MemberType NoteProperty -Name 'IsRemoteAppEnabled' -Value $isRemoteAppEnabled
$result | Add-Member -MemberType NoteProperty -Name 'SmbiosData' -Value $smbiosData

$result

}
## [END] Get-ServerInventory ##
function Install-MMAgent {
<#

.SYNOPSIS
Download and install Microsoft Monitoring Agent for Windows.

.DESCRIPTION
Download and install Microsoft Monitoring Agent for Windows.

.PARAMETER workspaceId
The log analytics workspace id a target node has to connect to.

.PARAMETER workspacePrimaryKey
The primary key of log analytics workspace.

.PARAMETER taskName
The task name.

.ROLE
Readers

#>

param(
    [Parameter(Mandatory = $true)]
    [String]
    $workspaceId,
    [Parameter(Mandatory = $true)]
    [String]
    $workspacePrimaryKey,
    [Parameter(Mandatory = $true)]
    [String]
    $taskName
)

$Script = @'
$mmaExe = Join-Path -Path $env:temp -ChildPath 'MMASetup-AMD64.exe'
if (Test-Path $mmaExe) {
    Remove-Item $mmaExe
}

Invoke-WebRequest -Uri https://go.microsoft.com/fwlink/?LinkId=828603 -OutFile $mmaExe

$extractFolder = Join-Path -Path $env:temp -ChildPath 'SmeMMAInstaller'
if (Test-Path $extractFolder) {
    Remove-Item $extractFolder -Force -Recurse
}

&$mmaExe /c /t:$extractFolder
$setupExe = Join-Path -Path $extractFolder -ChildPath 'setup.exe'
for ($i=1; $i -le 10; $i++) {
    if(-Not(Test-Path $setupExe)) {
        sleep -s 6
    }
}

&$setupExe /qn NOAPM=1 ADD_OPINSIGHTS_WORKSPACE=1 OPINSIGHTS_WORKSPACE_AZURE_CLOUD_TYPE=0 OPINSIGHTS_WORKSPACE_ID=$workspaceId OPINSIGHTS_WORKSPACE_KEY=$workspacePrimaryKey AcceptEndUserLicenseAgreement=1
'@

$Script = '$workspaceId = ' + "'$workspaceId';" + $Script
$Script = '$workspacePrimaryKey =' + "'$workspacePrimaryKey';" + $Script

$ScriptFile = Join-Path -Path $env:LocalAppData -ChildPath "$taskName.ps1"
$ResultFile = Join-Path -Path $env:temp -ChildPath "$taskName.log"
if (Test-Path $ResultFile) {
    Remove-Item $ResultFile
}

$Script | Out-File $ScriptFile
if (-Not(Test-Path $ScriptFile)) {
    $message = "Failed to create file:" + $ScriptFile
    Write-Error $message
    return #If failed to create script file, no need continue just return here
}

#Create a scheduled task
$User = [Security.Principal.WindowsIdentity]::GetCurrent()
$Role = (New-Object Security.Principal.WindowsPrincipal $User).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
$arg = "-NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -c $ScriptFile >> $ResultFile 2>&1"
if(!$Role)
{
  Write-Warning "To perform some operations you must run an elevated Windows PowerShell console."
}

$Scheduler = New-Object -ComObject Schedule.Service

#Try to connect to schedule service 3 time since it may fail the first time
for ($i=1; $i -le 3; $i++)
{
  Try
  {
    $Scheduler.Connect()
    Break
  }
  Catch
  {
    if($i -ge 3)
    {
      Write-EventLog -LogName Application -Source "SME Register $taskName" -EntryType Error -EventID 1 -Message "Can't connect to Schedule service"
      Write-Error "Can't connect to Schedule service" -ErrorAction Stop
    }
    else
    {
      Start-Sleep -s 1
    }
  }
}

$RootFolder = $Scheduler.GetFolder("\")
#Delete existing task
if($RootFolder.GetTasks(0) | Where-Object {$_.Name -eq $TaskName})
{
  Write-Debug("Deleting existing task" + $TaskName)
  $RootFolder.DeleteTask($TaskName,0)
}

$Task = $Scheduler.NewTask(0)
$RegistrationInfo = $Task.RegistrationInfo
$RegistrationInfo.Description = $TaskName
$RegistrationInfo.Author = $User.Name

$Triggers = $Task.Triggers
$Trigger = $Triggers.Create(7) #TASK_TRIGGER_REGISTRATION: Starts the task when the task is registered.
$Trigger.Enabled = $true

$Settings = $Task.Settings
$Settings.Enabled = $True
$Settings.StartWhenAvailable = $True
$Settings.Hidden = $False
$Settings.ExecutionTimeLimit  = "PT20M" # 20 minutes

$Action = $Task.Actions.Create(0)
$Action.Path = "powershell"
$Action.Arguments = $arg

#Tasks will be run with the highest privileges
$Task.Principal.RunLevel = 1

#Start the task to run in Local System account. 6: TASK_CREATE_OR_UPDATE
$RootFolder.RegisterTaskDefinition($TaskName, $Task, 6, "SYSTEM", $Null, 1) | Out-Null
#Wait for running task finished
$RootFolder.GetTask($TaskName).Run(0) | Out-Null
while($Scheduler.GetRunningTasks(0) | Where-Object {$_.Name -eq $TaskName})
{
  Start-Sleep -s 1
}

#Clean up
$RootFolder.DeleteTask($TaskName,0)
Remove-Item $ScriptFile

if (Test-Path $ResultFile)
{
    Get-Content -Path $ResultFile | Out-String -Stream
    Remove-Item $ResultFile
}

}
## [END] Install-MMAgent ##
function New-WindowsAdminCenterUpdateSchedule {
<#

.SYNOPSIS
Create a scheduled task to run a powershell script file to installs all available WAC updates through

.DESCRIPTION
Schedule an installation for a WAC Update using the task scheduler

.ROLE
Administrators

.PARAMETER installTime
  The user-defined time to install the update

#>

param (
    [Parameter(Mandatory = $true)]
    [string]$installTime
)

$Script = @'

function Get-CurrentSslCertificates([string]$portNumber) {
    Write-Host "Retieving current certificate for $portNumber"
    $netshCommand = "netsh http show sslcert ipport=0.0.0.0:{0}" -f $portNumber
    $portCertificate = (Invoke-Expression $netshCommand) -Join ' '
    $pattern = "Certificate hash\s+: (\w+)"
    $thumbprint = $portCertificate | Microsoft.PowerShell.Utility\Select-String -Pattern $pattern | ForEach-Object { $_ -match $pattern > $null; $matches[1] };
    return @{ thumbprint = $thumbprint }
}

$serviceFound = Get-Service ServerManagementGateway -ErrorAction SilentlyContinue
if ($null -eq $serviceFound) {
    $isServiceMode = $false
}
else {
    $isServiceMode = $true
}
$isHAEnabled = "false"
if (Test-Path -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway\Ha") {
    $HARegistryResult = Get-ItemPropertyValue -path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway\HA" -Name isHAEnabled
    $isHAEnabled = $HARegistryResult
}

$registryResult = Get-ItemPropertyValue -path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway" -Name SmePort
$port = $registryResult
$directoryForDownload = "$($env:Temp)"
$tempDlPath = $directoryForDownload + "\WAC.msi"
Invoke-WebRequest "http://aka.ms/wacdownload" -OutFile $tempDlPath
$logPath = "$($env:Temp)" + "\installLog.txt"

$certResults = Get-CurrentSslCertificates($port)
$certThumbprint = $certResults.thumbprint

if ($isHAEnabled -eq "true") {
    $zipFilePath = $directoryForDownload + "Install-WindowsAdminCenterHA-1907.zip"
    Invoke-WebRequest "http://aka.ms/WACHAScript" -OutFile $zipFilePath
    Expand-Archive -Path $zipFilePath -DestinationPath $directoryForDownload -Verbose -Force
    Remove-Item $zipFilePath
    Set-Location $directoryForDownload # so we can locate and run the install-WindowsAdminCenterHA.ps1 script
    .\Install-WindowsAdminCenterHA.ps1 -msiPath $tempDlPath -Verbose
}
else {
  if ($isServiceMode -eq $true) {
      Stop-Service ServerManagementGateway
  }
  else {
      Stop-Process -Name SmeDesktop
  }
  # Installation happens quietly in the background.
  if ($null -eq $certThumbprint) {
      Start-Process -NoNewWindow -Wait -FilePath 'msiexec.exe' `
          -ArgumentList "/i $tempDlPath /qn /L*v ""$($logPath)"" SME_PORT=$port SSL_CERTIFICATE_OPTION=generate" `
          -Passthru
  }
  else {
      Start-Process -NoNewWindow -Wait -FilePath "msiexec.exe" `
          -ArgumentList "/i $tempDlPath /qn /L*v ""$($logPath)"" SME_PORT=$port SME_THUMBPRINT=$certThumprint SSL_CERTIFICATE_OPTION=installed" `
          -Passthru
  }

  if ($isServiceMode -eq $true) {
      Restart-Service ServerManagementGateway
  }
  else {
      Start-Process "$env:ProgramFiles\Windows Admin Center\SmeDesktop.exe"
  }
}
# Deleting the WAC.msi file after the install is done
Remove-item $tempDlPath
'@

enum UpdateScheduleErrorCode {
    noError = 0
    scriptNotCreated = 1
    notAnAdmin = 2
    schedulerNoConnection = 3
}

$ScriptFile = $env:Temp + "\WACInstall-Updates.ps1"
$Script | Out-File $ScriptFile
if (-Not(Test-Path $ScriptFile)) {
    $message = "Failed to create file:" + $ScriptFile
    Write-Error $message
    #If failed to create script file, no need continue just return here
    return @{
        IsSuccess = $false
        ErrorCode = [UpdateScheduleErrorCode]::scriptNotCreated
    }
}


$User = [Security.Principal.WindowsIdentity]::GetCurrent()
$Role = (New-Object Security.Principal.WindowsPrincipal $User).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
if (!$Role) {
    Write-Warning "To perform some operations you must run an elevated Windows PowerShell console."
    return @{
        IsSuccess = $false
        ErrorCode = [UpdateScheduleErrorCode]::notAnAdmin
    }
}

$Scheduler = New-Object -ComObject Schedule.Service

#Try to connect to schedule service 3 time since it may fail the first time
for ($i = 1; $i -le 3; $i++) {
    Try {
        $Scheduler.Connect()
        Break
    }
    Catch {
        if ($i -ge 3) {
            Write-EventLog -LogName Application -Source "SME Windows Updates Install Updates" -EntryType Error -EventID 1 -Message "Can't connect to Schedule service"
            Write-Error "Can't connect to Schedule service" -ErrorAction Stop
            return @{
                IsSuccess = $false
                ErrorCode = [UpdateScheduleErrorCode]::schedulerNoConnection
            }
        }
        else {
            Start-Sleep -s 1
        }
    }
}


$RootFolder = $Scheduler.GetFolder("\")
#Create a scheduled task
$taskName = "WACInstallUpdates"
#Delete existing task
if ($RootFolder.GetTasks(0) | Where-Object { $_.Name -eq $taskName }) {
    Write-Debug("Deleting existing task" + $taskName)
    Unregister-ScheduledTask -TaskName 'WACInstallUpdates' -Confirm:$false
}

$taskTrigger = New-ScheduledTaskTrigger -Once -At $installTime
$taskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -WakeToRun -RunOnlyIfNetworkAvailable
$taskAction = New-ScheduledTaskAction `
    -Execute 'powershell.exe' `
    -Argument "-WindowStyle Hidden -File ""$($ScriptFile)"""

$description = "Update WAC to the latest version at the defined time"

$id = [System.Security.Principal.WellKnownSidtype]::BuiltinAdministratorsSid
$x = new-object System.Security.Principal.SecurityIdentifier -ArgumentList $id,$null
$translatedID = $x.Translate([System.Security.Principal.NTAccount])

$taskPrincipal = New-ScheduledTaskPrincipal -GroupId $translatedID.value -RunLevel Highest

# Register the scheduled task
Register-ScheduledTask `
    -TaskName $taskName `
    -Action $taskAction `
    -Trigger $taskTrigger `
    -Description $description `
    -Settings $taskSettings `
    -Principal $taskPrincipal


return @{
    IsSuccess = $true
    ErrorCode = [UpdateScheduleErrorCode]::noError
}

}
## [END] New-WindowsAdminCenterUpdateSchedule ##
function Remove-InstallUpdateScheduledTask {
<#

.SYNOPSIS
Deletes an already created scheduled task.
.DESCRIPTION

.ROLE
Administrators

#>

Unregister-ScheduledTask -TaskName 'WACInstallUpdates' -Confirm:$false

}
## [END] Remove-InstallUpdateScheduledTask ##
function Update-WindowsAminCenter {
<#

.SYNOPSIS
Install WAC Update

.DESCRIPTION
Instsall WAC Update.

.ROLE
Administrators

#>

function Get-CurrentSslCertificates([string]$portNumber) {
    Write-Host "Retieving current certificate for $portNumber"
    $netshCommand = "netsh http show sslcert ipport=0.0.0.0:{0}" -f $portNumber
    $portCertificate = (Invoke-Expression $netshCommand) -Join ' '
    $pattern = "Certificate hash\s+: (\w+)"
    $thumbprint = $portCertificate | Microsoft.PowerShell.Utility\Select-String -pattern $pattern | ForEach-Object { $_ -match $pattern > $null; $matches[1] };
    return @{ thumbprint = $thumbprint }
}

$serviceFound = Get-Service ServerManagementGateway -ErrorAction SilentlyContinue
if ($null -eq $serviceFound) {
    $isServiceMode = $false
}
else {
    $isServiceMode = $true
}
$isHAEnabled = "false"
if (Test-Path -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway\Ha") {
    $HARegistryResult = Get-ItemPropertyValue -path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway\HA" -Name isHAEnabled
    $isHAEnabled = $HARegistryResult
}

$registryResult = Get-ItemPropertyValue -path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\ServerManagementGateway" -Name SmePort
$port = $registryResult
$directoryForDownload = "$($env:Temp)"
$tempDlPath = $directoryForDownload + "\WAC.msi"
Invoke-WebRequest "http://aka.ms/wacdownload" -OutFile $tempDlPath
$logPath = "$($env:Temp)" + "\installLog.txt"

$certResults = Get-CurrentSslCertificates($port)
$certThumbprint = $certResults.thumbprint

if ($isHAEnabled -eq "true") {
    $zipFilePath = $directoryForDownload + "Install-WindowsAdminCenterHA-1907.zip"
    Invoke-WebRequest "http://aka.ms/WACHAScript" -OutFile $zipFilePath
    Expand-Archive -Path $zipFilePath -DestinationPath $directoryForDownload -Verbose -Force
    Remove-Item $zipFilePath
    Set-Location $directoryForDownload # so we can locate and run the install-WindowsAdminCenterHA.ps1 script
    .\Install-WindowsAdminCenterHA.ps1 -msiPath $tempDlPath -Verbose
}
else {
    if ($isServiceMode -eq $true) {
        Stop-Service ServerManagementGateway
    }
    else {
       Stop-Process -Name SmeDesktop
    }
    # Installation happens quietly in the background.
    if ($null -eq $certThumbprint) {
        Start-Process -NoNewWindow -Wait -FilePath 'msiexec.exe' `
            -ArgumentList "/i $tempDlPath /qn /L*v ""$($logPath)"" SME_PORT=$port SSL_CERTIFICATE_OPTION=generate" `
            -Passthru
    }
    else {
        Start-Process -NoNewWindow -Wait -FilePath "msiexec.exe" `
            -ArgumentList "/i $tempDlPath /qn /L*v ""$($logPath)"" SME_PORT=$port SME_THUMBPRINT=$certThumprint SSL_CERTIFICATE_OPTION=installed" `
            -Passthru
    }

    if ($isServiceMode -eq $true) {
        Restart-Service ServerManagementGateway
    }
    else {
        Start-Process "$env:ProgramFiles\Windows Admin Center\SmeDesktop.exe"
    }
}
Remove-item $tempDlPath

}
## [END] Update-WindowsAminCenter ##

# SIG # Begin signature block
# MIIjhQYJKoZIhvcNAQcCoIIjdjCCI3ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBbteM4bLSkuCfn
# P1hlDM5Ryav6NVavL0vBy7R1U4ObY6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVWjCCFVYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgkWoKZtmG
# Tdm2mexoxw3z6RgjFQHshhXlWtmdy+T/pGAwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBFbYHnb8feZ620i9qphn6KbPB0I6J+if4eoZwL1aNg
# zIaAxv7wFRSs9dmMWaHU1/wqY23K1qxLqh7FxYXjYJCBz80tTEEaPsBq7xwJDKeJ
# NLWCucmjzqR6C7o7n7lvOP+gOP7z78/qlT098eKcjFkGs6WnghXEaLdRC5MIQsvq
# NwvXByILB7cqV8fRj99fb9Uw5dQKBNLzH+yiRTV9Gkx6Yc+WGhZCaxR7hhGg4CgE
# VKUe5sKOCnmX/7Jn9tNLHrRKvHtN/4Erd6PefwaJN8cUCdeiDda2QaT4BrXMsOTz
# /5sbXXORr/ntRpRiuSTKgUovSRcByIJKpK+4rX/9/K0BoYIS5DCCEuAGCisGAQQB
# gjcDAwExghLQMIISzAYJKoZIhvcNAQcCoIISvTCCErkCAQMxDzANBglghkgBZQME
# AgEFADCCAVEGCyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIMaj0VnWs09tvW9JuO6FzzB6Jos1ZUHxS+pprf8f
# QKG0AgZgPQoNUKwYEzIwMjEwMzAxMTgzMDAwLjA0MVowBIACAfSggdCkgc0wgcox
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1p
# Y3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1Mg
# RVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFt
# cCBTZXJ2aWNloIIOOzCCBPEwggPZoAMCAQICEzMAAAFHnY/x5t4xg1kAAAAAAUcw
# DQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcN
# MjAxMTEyMTgyNTU1WhcNMjIwMjExMTgyNTU1WjCByjELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2Eg
# T3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTVBNi1FMjdDLTU5
# MkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCtBQNM6X32KFk/BJ8YaprfzEt6Lj34
# G+VLjzgfEgOGSVd1Mu7nCphK0K4oyPrzItgNRjB4gUiKq6GzgxdDHgZPgTEvm57z
# sascyGrybWkf3VVr8bqf2PIgGvwKDNEgVcygsEbuWwXz9Li6M7AOoD4TB8fl4ATm
# +L7b4+lYDUMJYMLzpiJzM745a0XHiriUaOpYWfkwO9Hz6uf+k2Hq7yGyguH8naPL
# MnYfmYIt2PXAwWVvG4MD4YbjXBVZ14ueh7YlqZTMua3n9kT1CZDsHvz+o58nsoam
# XRwRFOb7LDjVV++cZIZLO29usiI0H79tb3fSvh9tU7QC7CirNCBYagNJAgMBAAGj
# ggEbMIIBFzAdBgNVHQ4EFgQUtPjcb95koYZXGy9DPxN49dSCsLowHwYDVR0jBBgw
# FoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDov
# L2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENB
# XzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0
# cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDAN
# BgkqhkiG9w0BAQsFAAOCAQEAUMQOyjV+ea2kEtXqD0cOfD2Z2PFUIy5kLkGU53RD
# GcfhlzIR9QlTgZLqTEhgLLuCSy6jcma+nPg7e5Xg1oqCZcZJRwtRPzS1F6/M6YR3
# 5H3brN0maVnPrmrQ91kkfsNqDTtuWDiAIBfkNEgCpQZCb4OV3HMu5L8eZzg5dUaJ
# 7XE+LBuphJSLFJtabxYt4fkCQxnTD2z50Y32ZuXiNmFFia7qVq+3Yc3mmW02+/KW
# H8P1HPiobJG8crGYgSEkxtkUXGdoutwGWW88KR9RRcM/4GKLqt2OQ8AWEQb7shgM
# 8pxNvu30TxejRApa4WAfOAejTG4+KzBm67XjVZ2IlXAPkjCCBnEwggRZoAMCAQIC
# CmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRp
# ZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIx
# NDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF
# ++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRD
# DNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSx
# z5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1
# rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16Hgc
# sOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB
# 4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqF
# bVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1Ud
# EwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYD
# VR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEB
# BE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCB
# kjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQe
# MiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQA
# LiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUx
# vs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GAS
# inbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1
# L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWO
# M7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4
# pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45
# V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x
# 4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEe
# gPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKn
# QqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp
# 3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvT
# X4/edIhJEqGCAs0wggI2AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBP
# cGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUyN0MtNTky
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAq6fBtEENocNASMqL03zGJS0wZd2ggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOPniI0wIhgPMjAy
# MTAzMDEyMzM2NDVaGA8yMDIxMDMwMjIzMzY0NVowdjA8BgorBgEEAYRZCgQBMS4w
# LDAKAgUA4+eIjQIBADAJAgEAAgEHAgH/MAcCAQACAhGTMAoCBQDj6NoNAgEAMDYG
# CisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEA
# AgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAhRm2tk27rnz6V4tz7L0yZJFnmWa27ujj
# UdoWX/1c+ITKZ3iPIxfHJDbjmT23jUQwkgagbfN40+438D2XtwpoF6rJY82eO3gq
# hULR427OmsfPT8ruNf74b+OWUqFeCPXR7/Z51izSpjuEW1Hm8OHUJYpBtuEP8r2F
# d4vn45goi4kxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAUedj/Hm3jGDWQAAAAABRzANBglghkgBZQMEAgEFAKCCAUowGgYJ
# KoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAMFiXHIMRv
# b3I37lZVIZDMkrAmPcT/JANUe5YqWKGHNDCB+gYLKoZIhvcNAQkQAi8xgeowgecw
# geQwgb0EIHvbPBIDlM+6BsiJk7/YfWGuKwBUi3DMOxxvRaqKGOmFMIGYMIGApH4w
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFHnY/x5t4xg1kAAAAA
# AUcwIgQg0aFQL3CzhbFxNiy5moUkpsX30aPw9kmjVZyXkmF0I9owDQYJKoZIhvcN
# AQELBQAEggEAIpQcv68KWZLK51HQ3Ae4/q1znML3AvDM89fwDYns9OTbuUvljFl8
# kwC7gpC8J5PoF8kr/UyHqtiM3qor8Y9uehkhEiM1Ek50wQRfgTMd4sa5G7Ow5PW8
# gFn6ryqowVb4HYGIuNL9m0ItXe8S4saU63gprS/RZZFbcwYPsh85kzoMN46++cJs
# u6ylQm+X6d2OVaKvOYsaFfRvjqBfOkcdHkoGBtat39Wik8BchPKCb/bd/o/zg0w7
# mUlpJTBNDA41+oNzYSsSOtFZNHMkSo21aeMM4F3vsmw3xNwGJ4fnPrVJQBjteXFn
# kqJVUz75Cjo7vBoxsDar4UQNzyPHlGo79Q==
# SIG # End signature block
