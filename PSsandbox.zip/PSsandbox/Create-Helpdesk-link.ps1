Remove-Item "C:\Users\Public\Desktop\Cummings Helpdesk.url"' -Force
$Base64 = "W3swMDAyMTRBMC0wMDAwLTAwMDAtQzAwMC0wMDAwMDAwMDAwNDZ9XQ0KUHJvcDM9MTksMTENCltJbnRlcm5ldFNob3J0Y3V0XQ0KSURMaXN0PQ0KVVJMPWh0dHBzOi8vaGVscGRlc2suY3VtbWluZ3NhZXJvc3BhY2UuY29tL3NlcnZpY2VkZXNrL2N1c3RvbWVyL3BvcnRhbC8NCkljb25JbmRleD0wDQpIb3RLZXk9MA0KSWNvbkZpbGU9QzpcV2luZG93c1xTeXN0ZW0zMlxIZWxwZGVzay5pY28="
$URL = "C:\Users\Public\Desktop\Helpdesk.url"
$Content = [System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String($Base64))
Set-Content $URL $Content