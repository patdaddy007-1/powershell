######################################################################################
# Created by Anthony Soprano on behalf of Techni-Core Network Services, Inc.         #
# Date Created: June 20, 2020                                                        #
# Generate a list of BitLocker recovery keys and display them at the command prompt. #
######################################################################################
 
# 1. Run PowerShell as Administrator
# 2. Change Directory to where this .ps1 file is located
# 3. Run .\Get-BitlockerRecovery.ps1
 
# Identify all the BitLocker volumes.
$BitlockerVolumes = Get-BitLockerVolume
$Path = "\\ca.local\SharedData\Data\Corporate\InformationTechnology\Security\Bitlocker\" 
# For each volume, get the RecoveryPassword and export it to a text file.
$BitlockerVolumes |
    ForEach-Object {
        $MountPoint = $_.MountPoint -replace ":",""
        $RecoveryKey = [string]($_.KeyProtector).RecoveryPassword       
        if ($RecoveryKey.Length -gt 5) {
            Write-Output ("$RecoveryKey") > $Path\$env:computername-$MountPoint-BitlockerRecoveryKey.txt
        }        
    }
