#This is a work in progress and will be updated as the update requirements on the target evolve
#This is the initial rough draft, but encoompasses the nature of the script
#Due to the above, there will be discrepancies between this and the production version, until the production version reaches its final form

#Disable smartscreen
reg import .\disable-SScreen.reg
# go to the update repo
cd c:\update
#establich file and folder paths as variables
$file = dir *.msu -file | select -ExpandProperty fullname
$file2 = $file -replace '\-x.+',""                                                                                
$file2 = $file2 -replace '^.+\-',""                                                                               
$DPath = "C:\Temp\$file2"                    
#create the destination folder
md $DPath                                                                                                         
cd $DPath                     
#expand package
expand _f:* $file $DPath
$package = dir "win*.cab" -File | select -ExpandProperty fullname                                                 
#install package
Add-WindowsPackage -Online -PackagePath $package -NoReboot                                                              
#install definition updates if present and needed
&"C:\update\mpam-fe.exe"  -EA -0
#re-enable smartscreen
reg import .\enable-SScreen.reg
#reboot
Restart-Computer  
