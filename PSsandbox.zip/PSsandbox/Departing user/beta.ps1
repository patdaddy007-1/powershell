# Departing user script
# authored by: Patrick Whitlock
# script creation began 11/20/2020 @ 10:00am
#############################################
param ($UName)
if ($UName -eq $null){
$UName = Read-Host -Prompt "Please enter user logon name"
}
$props=[ordered]@{
	UserName=''
	Department=''
	email=''
	aliases=''
	Groups=''
}
# Script wide variables
$Initals = Read-Host -Prompt "Please enter your initials"
$DDate = get-date -Format MM/dd/yyyy
$DestOU = "OU=Disabled Users,DC=ca,DC=local"
Disabled on $DDate - $Initals
###################################################
$UserData = Get-ADUser $UName -Properties * | select *
$TimeNow = Get-Date
# Get groups
$ADGroups = @()
$ADGroups += (Get-ADPrincipalGroupMembership $UName | select -ExpandProperty name)
# email address
$email = $UserData.EmailAddress
$Dept = $UserData.Department
$Created = $UserData.whenCreated






#disable account if not already disabled
if ($UserData.Enabled){
"User account is enabled. Disabling"
Set-ADUser $UName -Enabled:$False
} else {
"User account is already disabled"
}
#Move user to disabled user OU
"Moving user to Disabled Users OU"
Get-ADUser $UName | Move-ADObject -TargetPath $DestOU

"Generating user report for" $UserData.DisplayName
$props=[ordered]@{
	UserName=$UName
	Department=$Dept
	email=$email
	aliases='N/A'
	Groups=''
}
#New-Object PsObject -Property $props | Export-Csv C:\Temp\UserReport.csv -NoTypeInformation
####################################################################
#########################NOTES######################################
<# These commands have been tested and confirmed to be working
$Users = @(
"ahenson"
"csallis"
)
function Depart-Users{
$Initals = Read-Host -Prompt "Please enter your initials"
$DDate = get-date -Format MM/dd/yyyy
$DestOU = "OU=Disabled Users,DC=ca,DC=local"
$desc = "Disabled on $DDate - $Initals"
foreach ($U in $Users){
"updating description"
set-aduser $U -description $desc
"disabling user $U"
Set-ADUser $U -Enabled:$False
#Move user to disabled user OU
"Moving user to Disabled Users OU"
Get-ADUser $U | Move-ADObject -TargetPath $DestOU
"Changing password"
Set-ADAccountPassword -Identity $U -NewPassword (ConvertTo-SecureString -AsPlainText "D3@rly D3parted" -Force)
}
}


foreach ($U in $Users){
set-aduser $U -description $desc
}

 #>