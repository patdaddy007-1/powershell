$COUNTERCURSOR = 7
$EPOCH = Get-Date -Year 1970 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0
$INTERVAL = 30
$OTPLENGTH = 6
# $SHAREDSECRET must be base64 encoded
$SHAREDSECRET = "R1kzVUdNWlFJTTNESVJKWUhGQkVDUlJSSUZDRU1OU0RJVTNVS09CWUlNWlRLTkJRR1UzRU1RSlpJWkNUUVJKVg=="

function GetCounter(){
    # calculate seconds since epoch (UNIX time)
    $span = New-TimeSpan -Start $EPOCH -End (Get-Date).ToUniversalTime()
    $seconds = [math]::floor($span.TotalSeconds)
    $counter = [math]::floor($seconds / $INTERVAL)
    $counter = [Convert]::ToInt32($seconds / $INTERVAL)
    # calculate the counter bytes
    $counterBytes = New-Object Byte[] 8
    while (($counter -gt 0) -and ($COUNTERCURSOR -ge 0)) {
	   $counterBytes[$COUNTERCURSOR] = ($counter -band 0xff)
	   $counter = [math]::floor($counter / [math]::pow(2, 8))
	   $COUNTERCURSOR -= 1
    }
    GetOtp($counterBytes)
}

function GetOtp($cb){
    # generate SHA1 HMAC from $counterBytes using $SHAREDSECRET as the key
    $enc = [System.Text.Encoding]::UTF8
    $hmac = New-Object -TypeName System.Security.Cryptography.HMACSHA1
    $hmac.key = [System.Convert]::FromBase64String($SHAREDSECRET)
    $randHash = $hmac.ComputeHash($cb)
    
    # create an OTP compatable with http://tools.ietf.org/html/rfc4226#section-5.3
    $offset = $randhash[19] -band 0xf
    $fullOTP = ($randhash[$offset] -band 0x7f) * [math]::pow(2, 24)
    $fullOTP += ($randHash[$offset + 1] -band 0xff) * [math]::pow(2, 16)
    $fullOTP += ($randHash[$offset + 2] -band 0xff) * [math]::pow(2, 8)
    $fullOTP += ($randHash[$offset + 3] -band 0xff)
    $modNumber = [math]::pow(10, $OTPLENGTH)
    $otp = $fullOTP % $modNumber
    # zero pad to $OTPLENGTH digits
    $otp = $otp.ToString("0" * $OTPLENGTH)
    return $otp
}

GetCounter