#pragma once
// PST related utilities for MrMAPI

void DoPST();