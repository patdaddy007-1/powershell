#pragma once
// Profile dumping for MrMAPI

namespace output
{
	void DoProfile();
}