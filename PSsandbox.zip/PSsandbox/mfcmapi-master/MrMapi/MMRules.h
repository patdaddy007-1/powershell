#pragma once
// Rule table dumping for MrMAPI

void DoRules(_In_opt_ LPMAPIFOLDER lpFolder);
