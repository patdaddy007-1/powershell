#pragma once
// MAPI <-> MIME conversion for MrMAPI

void DoMAPIMIME(_In_opt_ LPMAPISESSION lpMAPISession);