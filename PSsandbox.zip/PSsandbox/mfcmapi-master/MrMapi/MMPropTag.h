#pragma once
// Prop tag parsing for MrMAPI

void DoPropTags();
void DoGUIDs() noexcept;
void DoFlagSearch() noexcept;