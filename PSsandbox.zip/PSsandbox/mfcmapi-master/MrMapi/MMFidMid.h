#pragma once
// Fid / Mid lookup

void DoFidMid(_In_opt_ LPMDB lpMDB);
