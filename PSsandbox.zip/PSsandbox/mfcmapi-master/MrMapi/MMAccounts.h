#pragma once
// Account enum for MrMAPI

void DoAccounts(_In_opt_ LPMAPISESSION lpMAPISession);