#pragma once
// ReceiveFolder related stuff for MrMAPI

void DoReceiveFolder(_In_opt_ LPMDB lpMDB);