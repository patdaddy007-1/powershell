#pragma once
// Error code parsing for MrMAPI

void DoErrorParse();