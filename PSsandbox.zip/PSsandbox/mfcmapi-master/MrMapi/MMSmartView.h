#pragma once
// Smart View parsing for MrMAPI

void DoSmartView();