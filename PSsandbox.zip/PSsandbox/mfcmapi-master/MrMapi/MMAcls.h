#pragma once
// Acl table dumping for MrMAPI

void DoAcls(_In_opt_ LPMAPIFOLDER lpFolder);
void DumpExchangeTable(_In_ ULONG ulPropTag, _In_opt_ LPMAPIFOLDER lpFolder);