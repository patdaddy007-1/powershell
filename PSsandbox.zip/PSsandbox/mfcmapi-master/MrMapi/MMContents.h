#pragma once
// Contents table output for MrMAPI

void DoContents(LPMDB lpMDB, LPMAPIFOLDER lpFolder);
void DoMSG();