#pragma once

class CMainDlg;

namespace dialog::editor
{
	void OnQSCheckSpecialFolders(_In_ CMainDlg* lpHostDlg, _In_ HWND hwnd);
} // namespace dialog::editor