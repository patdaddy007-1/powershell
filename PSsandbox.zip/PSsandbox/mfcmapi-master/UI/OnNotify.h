#pragma once

namespace mapi::mapiui
{
	void OnNotify(HWND hWndParent, HTREEITEM hTreeParent, ULONG cNotify, LPNOTIFICATION lpNotifications);
} // namespace mapi::mapiui