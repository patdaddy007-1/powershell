#pragma once
#include <AclUI.h>
#include <core/interpret/sid.h>

namespace mapi::mapiui
{
	class CMySecInfo : public ISecurityInformation, ISecurityInformation2
	{
	public:
		CMySecInfo(_In_ LPMAPIPROP lpMAPIProp, ULONG ulPropTag);
		virtual ~CMySecInfo();

		STDMETHODIMP QueryInterface(_In_ REFIID riid, _Deref_out_opt_ LPVOID* ppvObj) override;
		STDMETHODIMP_(ULONG) AddRef() override;
		STDMETHODIMP_(ULONG) Release() override;

		// *** ISecurityInformation methods ***
		STDMETHODIMP GetObjectInformation(PSI_OBJECT_INFO pObjectInfo) override;
		STDMETHODIMP GetSecurity(
			SECURITY_INFORMATION RequestedInformation,
			PSECURITY_DESCRIPTOR* ppSecurityDescriptor,
			BOOL fDefault) override;
		STDMETHODIMP
		SetSecurity(SECURITY_INFORMATION SecurityInformation, PSECURITY_DESCRIPTOR pSecurityDescriptor) override;
		STDMETHODIMP GetAccessRights(
			const GUID* pguidObjectType,
			DWORD dwFlags,
			PSI_ACCESS* ppAccess,
			ULONG* pcAccesses,
			ULONG* piDefaultAccess) override;
		STDMETHODIMP MapGeneric(const GUID* pguidObjectType, UCHAR* pAceFlags, ACCESS_MASK* pMask) override;
		STDMETHODIMP GetInheritTypes(PSI_INHERIT_TYPE* ppInheritTypes, ULONG* pcInheritTypes) override;
		STDMETHODIMP PropertySheetPageCallback(HWND hwnd, UINT uMsg, SI_PAGE_TYPE uPage) override;

		// *** ISecurityInformation2 methods ***
		STDMETHODIMP_(BOOL) IsDaclCanonical(PACL pDacl) override;
		STDMETHODIMP LookupSids(ULONG cSids, PSID* rgpSids, LPDATAOBJECT* ppdo) override;

	private:
		LONG m_cRef;
		LPMAPIPROP m_lpMAPIProp;
		ULONG m_ulPropTag;
		LPBYTE m_lpHeader;
		ULONG m_cbHeader;
		sid::aceType m_acetype;
		std::wstring m_wszObject;
	};
} // namespace mapi::mapiui