#pragma once

namespace version
{
	std::wstring GetOutlookVersionString();
} // namespace version