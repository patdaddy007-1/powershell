﻿#include <core/stdafx.h>
#include <core/sortlistdata/propListData.h>
#include <core/sortlistdata/sortListData.h>

namespace sortlistdata
{
	void propListData::init(sortListData* data, _In_ ULONG ulPropTag)
	{
		if (!data) return;

		data->init(std::make_shared<propListData>(ulPropTag), true);
	}

	propListData::propListData(_In_ ULONG ulPropTag) noexcept : m_ulPropTag(ulPropTag) {}
} // namespace sortlistdata