﻿#pragma once

namespace sortlistdata
{
	class IData
	{
	public:
		virtual ~IData() {}
	};
} // namespace sortlistdata