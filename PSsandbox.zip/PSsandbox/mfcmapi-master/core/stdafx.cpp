#include <core/stdafx.h>
