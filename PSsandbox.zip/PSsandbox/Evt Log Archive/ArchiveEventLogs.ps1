#Beginning section, set some variables and check for needed folder.

#Check to see if the DataPath Env variable exists and sets it to c:\data if not.
$QueryDataPath = [environment]::GetEnvironmentVariable("DataPath","Machine")

if($QueryDataPath -ne $null){
#DataPath already exists, so use it to set variable.
$DataPath = $QueryDataPath
} Else {
#It doesn't exist, so set it to the default value, then set the in-script variable to the default value as well.
[Environment]::SetEnvironmentVariable("DataPath", "C:\Data", "Machine")
$DataPath = "C:\Data"
}

#Define 7za.exe executable path.
$7zpath = "C:\Temp\7za.exe" 

#Set computer name variable
$computername = gc env:computername

#Enable retention (1gb files) for Application, System, and Security event logs.
wevtutil.exe sl Security /rt:true /ab:true /ms:1073741824
wevtutil.exe sl System /rt:true /ab:true /ms:1073741824
wevtutil.exe sl Application /rt:true /ab:true /ms:1073741824

#Check to see if $DataPath\Security\Eventlogs exists and create it if not.
if (-not(Test-Path -Path $DataPath\Security\Eventlogs)) {
New-Item -ItemType directory -Path $DataPath\Security\Eventlogs
}

#Define functions

#retry function
function Retry()
{
    param(
        [Parameter(Mandatory=$true)][Action]$action,
        [Parameter(Mandatory=$false)][int]$maxAttempts = 180
    )
	$global:RetrySuccessful = "0"
    $attempts=1    
    $ErrorActionPreferenceToRestore = $ErrorActionPreference
    $ErrorActionPreference = "Stop"

    do
    {
        try
        {
            $action.Invoke();
			$global:RetrySuccessful = "1"
            break;
        }
        catch [Exception]
        {
            Write-Host $_.Exception.Message
        }

        # exponential backoff delay
        $attempts++
        if ($attempts -le $maxAttempts) {
            $retryDelaySeconds = "5"
            Write-Host("Action failed. Waiting " + $retryDelaySeconds + " seconds before attempt " + $attempts + " of " + $maxAttempts + ".")
            Start-Sleep $retryDelaySeconds 
        }
        else {
            $ErrorActionPreference = $ErrorActionPreferenceToRestore
            Write-Error $_.Exception.Message
        }
    } while ($attempts -le $maxAttempts)
    $ErrorActionPreference = $ErrorActionPreferenceToRestore
}

#Function to strip invalid characters from file name before it's used in other functions.
Function GetFileName([ref]$fileName)
{
	$invalidChars = [io.path]::GetInvalidFileNamechars() 
	$date = Get-Date -format s
	$fileName.value = ("Archive-" + $eventlogname + "_log_" + $computername + "_" + ($date.ToString() -replace "[$invalidChars]","-") + ".evtx")
}


#Main event log archive function. Does almost all the work of the script. Clears chosen event log, puttings its contents into a file named Archive-EventLogName_log_hostname_date_time.evtx, then archives those and any other archive named evtx files from c:\windows\system32\winevt\logs, puts them in DataPath\security\eventlogs folder.
Function ArchiveEventLogs([string]$eventlogname)
{
	#Invoke-Process lets us run executables and properly handle their stdout, stderr, and exit codes.
	function Invoke-Process {
	    [CmdletBinding(SupportsShouldProcess)]
	    param
	    (
	        [Parameter(Mandatory)]
	        [ValidateNotNullOrEmpty()]
	        [string]$FilePath,

	        [Parameter()]
	        [ValidateNotNullOrEmpty()]
	        [string]$ArgumentList
	    )

	    try {
	        $stdOutTempFile = "$env:TEMP\$([System.IO.Path]::GetRandomFileName())"
	        $stdErrTempFile = "$env:TEMP\$([System.IO.Path]::GetRandomFileName())"

	        $startProcessParams = @{
	            FilePath               = $FilePath
	            ArgumentList           = $ArgumentList
	            RedirectStandardError  = $stdErrTempFile
	            RedirectStandardOutput = $stdOutTempFile
	            Wait                   = $true;
	            PassThru               = $true;
	            NoNewWindow            = $true;
	        }
	        if ($PSCmdlet.ShouldProcess("Process [$($FilePath)]", "Run with args: [$($ArgumentList)]")) {
	            $cmd = Start-Process @startProcessParams
	            $cmdOutput = Get-Content -Path $stdOutTempFile -Raw
	            $cmdError = Get-Content -Path $stdErrTempFile -Raw
	            if ($cmd.ExitCode -ne 0) {
					$global:InvokeProcessError = "$cmdError"
	                if ($cmdError) {
	                    throw $cmdError.Trim()
	                }
	                if ($cmdOutput) {
	                    throw $cmdOutput.Trim()
	                }
	            } else {
	                if ([string]::IsNullOrEmpty($cmdOutput) -eq $false) {
	                    Write-Output -InputObject $cmdOutput
	                }
	            }
	        }
	    } catch {
	        $PSCmdlet.ThrowTerminatingError($_)
	    } finally {
	        Remove-Item -Path $stdOutTempFile, $stdErrTempFile -Force -ErrorAction Ignore
	    }
	}

	$fileName = $null
	GetFileName([ref]$fileName)
	$datetime = get-date
	#Clear the Target Event Log and archive it to file.
	wevtutil cl $eventlogname /bu:%systemroot%\system32\winevt\logs\$fileName
	
	#Append any Archive-TargetEventLog*.evtx files from default log location to 7z and delete if successful
	$filter = ("Archive-" + $eventlogname + "*.evtx")
	$archivelogs = Get-ChildItem "c:\windows\System32\winevt\logs" -Filter Archive-$eventlogname*.evtx
	Foreach ($archivelog in $archivelogs) {
		#Clear the Invoke Process error variable for this loop.
		$global:InvokeProcessError = 0
		$filenameWithoutExtension = ($DataPath + "\Security\Eventlogs\" + $computername + "_" + $eventlogname + "_log_" + $datetime.Year + "_" + $datetime.Month + "_")
		$filename = ($DataPath + "\Security\Eventlogs\" + $computername + "_" + $eventlogname + "_log_" + $datetime.Year + "_" + $datetime.Month + "_.7z")
		$EventLogsArchiveFolder = ($DataPath + "\Security\Eventlogs")
		$thisitem = ($archivelog.FullName)
		#Copy log to event log archive location, then delete the original if copy successful.
		try {
			$copiedFile = Copy-Item -Path "$thisitem" -Destination "$EventLogsArchiveFolder" -PassThru
				if (-not $copiedFile) {
					"Copy failed! Not deleting original EVTX file in system32\winevt\logs"
					$error[0].exception.message
			} else {
			Remove-Item $thisitem
				}
			}
			catch
				{
					"Copy failed with terminating error."
					$error[0].exception.message
				} finally {
					}
		$argumentList = "a -t7z -mx1 `"$filename`" `"$copiedFile`""
		"Having 7-zip archive $thisitem"
		#Invoke 7-zip here to archive the copied log file.
		try {
			$output = Invoke-Process -ErrorAction Continue -FilePath "$7zpath" -ArgumentList $argumentList
			Write-Output $output
			#important: If 7zip fails to rename the .tmp file it creates to the destination .7z file, it will fail. This code will handle that failure and wait 3 seconds, then rename the .tmp file where 7zip failed. If this doesn't happen, the original .7z will remain deleted, and the .tmp file will remain left behind in the eventlogs archive folder.
			} catch {
			"7-zip archive failed with terminating error."
			$error[0].exception.message
			} finally {}
		if ($error[0] -match "Cannot create a file when that file already exists") {
				Write-Host "7-zip failed to rename the .tmp file, so doing it for it."
				Start-Sleep 3
				Retry({Move-Item -Path "$filenameWithoutExtension.7z.tmp" -Destination "$filenameWithoutExtension.7z" -Force})
			}
		#Delete log file copy if no errors occurred and archive was successful.
		#Check if Invoke-Process set the global error variable to 1.
		if ($global:InvokeProcessError -ne 0) {
				if ($global:InvokeProcessError -like "Cannot create a file when that file already exists") {
					#The InvokeProcess error was just the can't create file when that file already exists problem we were expecting, so make sure rename above worked, then delete the evtx file.
					if ($global:RetrySuccessful = "1") {
						"No problems with archive operation, so deleting the original log file $thisitem"
						Remove-Item -Path $copiedFile
					}
				}
					else
					{
						$error[0]
						"Failed to append to 7z"
					}
			} Else {
			"No problems with archive operation, so deleting the original log file $thisitem"
			Remove-Item -Path $copiedFile
			}
		}
}

#Call the ArchiveEventLogs function to archive the event logs.
ArchiveEventLogs "Application"
ArchiveEventLogs "System"
ArchiveEventLogs "Security"

#Check for any leftover .tmp files in eventlogs archive folder. If found, throw error.
if (Get-ChildItem "$DataPath\Security\Eventlogs" -Filter *.tmp*)
	{
	throw "Found tmp file(s) when operation is complete, something is wrong."
	}

function Test-EventLog {
    Param(
        [Parameter(Mandatory=$true)]
        [string] $LogName
    )

    [System.Diagnostics.EventLog]::SourceExists($LogName)
}

#If no errors with script, log success to event log.
If (!($error)) {
"No errors were encountered, so logging success to Application event log, event 41492."
	If (!(Test-Eventlog "CAS-Automation")) {
			"Event log source 'CAS-Automation' not yet registered, so registering it."
			New-EventLog -LogName Application -Source "CAS-Automation"
		}
		Write-EventLog -LogName "Application" -Source "CAS-Automation" -EventId 41492 -EntryType Information -Message "Event Logs archived successfully to $DataPath\Security\Eventlogs" -Category 1
}