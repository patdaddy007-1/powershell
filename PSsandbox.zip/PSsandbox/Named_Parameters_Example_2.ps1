param ($servername, $envname)
write-host "If this script were really going to do something, it would do it on $servername in the $envname environment" 
