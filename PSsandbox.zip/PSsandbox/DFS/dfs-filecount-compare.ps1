$date = Get-Date -Format M-d-yy
$shareslist = dir "D:\\Data\Corporate" -directory |select -ExpandProperty name
foreach ($S in $shareslist){
$Folders = (dir "D:\\Data\Corporate\$S" -directory |select -ExpandProperty FullName)  -replace 'D:','D$'

foreach ($F in $Folders){
$PathName = $F -replace '^.+\\',""
$RGWfilecount = (dir \\srv-vm-rgw-fs1\$F\ -file -recurse -EA 0).count
$NICfilecount = (dir \\srv-vm-nic-dc1\$F\ -file -recurse -EA 0).count
$dataHash = $null
            $dataHash = [ordered]@{
                ParentFolder       = $S
                FolderName         = $PathName
                NicevilleCount     = $NICfilecount
                GatewayCount       = $RGWfilecount
				Match              = ($RGWfilecount -eq $NICfilecount)
            }
            $reportObject = New-Object PSObject -Property $dataHash
            $reportObject | Export-Csv C:\temp\DFS-count-report$date.csv -NoTypeInformation -Append
	}
}