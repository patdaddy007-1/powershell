$shareslist = dir "D:\\Data\Corporate" -directory |select -ExpandProperty name
foreach ($S in $shareslist){
$Folders = (dir "D:\\Data\Corporate\$S" -directory |select -ExpandProperty FullName)  -replace 'D:','D$'

foreach ($F in $Folders){
$PathName = $F -replace '^.+\\',""
$Log = "c:\temp\DFS copy logs\$S\$PathName.txt"
$RGWfilecount = (dir \\srv-vm-rgw-fs1\$F\ -file -recurse).count
$NICfilecount = (dir \\srv-vm-nic-dc1\$F\ -file -recurse).count
IF ($RGWfilecount -eq $NICfilecount){"Folder $F matches"
} ELSE {
"Count mismatch on folder $F. RGW:$RGWfilecount - NIC:$NICfilecount `nCopying contents from Gateway to Niceville "
robocopy "\\srv-vm-rgw-fs1\$F\\" "\\srv-vm-nic-dc1\$F\\" /e /b /copyall /r:6 /w:5 /MT:64 /tee /log+:$Log /v

}}
}