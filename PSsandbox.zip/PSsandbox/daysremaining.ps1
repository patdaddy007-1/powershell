Add-Type -AssemblyName PresentationFramework
$DaysRemaining = (90-(New-TimeSpan -Start (get-aduser $env:username -Properties *).PasswordLastSet).Days)
[System.Windows.MessageBox]::Show("$DaysRemaining",'Days remaining on current password','Ok','Information')