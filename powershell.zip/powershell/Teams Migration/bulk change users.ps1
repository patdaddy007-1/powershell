reg import "C:\Users\pwhitlock\Desktop\Allow Basic Auth.reg"
$UserCredential = Get-Credential -Credential 'patrick.whitlock@cummingsaerospace.com'
Connect-ExchangeOnline -Credential $UserCredential -ShowProgress $true -ExchangeEnvironmentName O365USGovGCCHigh
Import-Module SkypeOnlineConnector 
$sfbSession = New-CsOnlineSession -Credential $UserCredential
Import-PSSession $sfbSession 
$users = Get-DistributionGroupMember -Identity "CAstaff"| select -ExpandProperty PrimarySmtpAddress
foreach($User in $Users) { 
Grant-CsTeamsUpgradePolicy -Identity "SIP:$User" -PolicyName UpgradeToTeams 
}

#######################################################################################
# Check migration status:
# Get-CsMeetingMigrationStatus | select UserPrincipalName,State,LastMessage,CreateDate,ModifiedDate | ft
#######################################################################################
# $users = Get-DistributionGroupMember -Identity "CA-Huntsville"| select -ExpandProperty PrimarySmtpAddress

Grant-CsTeamsUpgradePolicy -PolicyName UpgradeToTeams -Identity $SipAddress