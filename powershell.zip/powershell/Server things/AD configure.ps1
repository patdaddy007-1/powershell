#Thing that need to happen:
# check the settings on the interactive logon policy after import and script update if needed
#export DDCP for AA with guest addition
#script update for path in whatcontainer policy

# Enable local admin account and reset password
$SafePass = ConvertTo-SecureString "Tric3ratops" -AsPlainText -Force
Get-LocalUser -Name "Administrator" | Enable-LocalUser
Set-LocalUser -Name "Administrator" -Password $SafePass
# Domain/Forest configuration
$SafePass = ConvertTo-SecureString "Tric3ratops" -AsPlainText -Force
Install-windowsfeature AD-domain-services -IncludeManagementTools

Import-Module ADDSDeployment

Install-ADDSForest `
-SafeModeAdministratorPassword $SafePass `
-CreateDnsDelegation:$false `
-DatabasePath "C:\Windows\NTDS" `
-DomainMode "WinThreshold" `
-DomainName "hq.contoso.com" `
-DomainNetbiosName "HQ" `
-ForestMode "WinThreshold" `
-InstallDns:$true `
-LogPath "C:\Windows\NTDS" `
-NoRebootOnCompletion:$false `
-SysvolPath "C:\Windows\SYSVOL" `
-Force:$true

# Install Print & Document Services role. Only Print Server role service should be installed.
Install-WindowsFeature Print-Server -IncludeManagementTools
#Install DHCP Role if the server is the primary server. (DNS and GP MMC should auto create on DCPROMO
# REBOOT NEEDED HERE
Install-WindowsFeature -Name 'DHCP' -IncludeManagementTools
# Build SHCP Scope and configure options
$address = Get-NetIPAddress | where {($_.AddressFamily -eq "IPv4") -and ($_.InterfaceAlias -notlike "Loopback*")} | select -ExpandProperty IPAddress
$localIP = (([ipaddress] $address).GetAddressBytes()[0..2] -join ".")
Add-DhcpServerV4Scope -Name "Primary DHCP Scope" -StartRange "$localIP.100" -EndRange "$localIP.199" -SubnetMask 255.255.255.0
Set-DhcpServerV4OptionValue -DnsServer $address -Router "$localIP.254"
Set-DhcpServerv4Scope -ScopeId $address -LeaseDuration 00:08:00
Add-DhcpServerInDC
# Disable root hints on DNS forwarder 
Set-DnsServerForwarder -IPAddress "8.8.8.8","8.8.4.4" -UseRootHint $false -PassThru
# update DNS in IPconfig
$index = (Get-NetIPAddress | where {($_.AddressFamily -eq "IPv4") -and ($_.InterfaceAlias -notlike "Loopback*") -and ($_.PrefixLength -eq 24)}).InterfaceIndex
$address = (Get-NetIPAddress | where {($_.AddressFamily -eq "IPv4") -and ($_.InterfaceAlias -notlike "Loopback*") -and ($_.PrefixLength -eq 24)}).IPAddress
Set-DnsClientServerAddress -InterfaceIndex $index -ServerAddresses ($address)
# Install DFS Namespace role
Install-windowsfeature FS-DFS-Namespace -IncludeManagementTools
# Install DFS replication role
Install-windowsfeature FS-DFS-Replication -IncludeManagementTools
# Create Data folder
New-Item "D:\Data" -Type Directory -ErrorAction SilentlyContinue
# share data folder
# Create DFS folder (this isn't working yet)
New-DfsnRoot -TargetPath "\\$env:computername\Data" -Type DomainV2 -Path "\\$env:userdomain\DFSData"
New-DfsnFolder -Path "\\$env:userdnsdomain\DFSData\Data" -TargetPath "$env:computername\Data"
# create shares
$shares = @(
"Genapps"
"Shared"
"Junk"
"UserHomes"
"UserProfiles"
"UserTSProfiles"
)
foreach ($folder in $shares){
New-Item "D:\Data\$folder" -Type Directory
}
# Create OUs
$Units = @(
"Domain Users"
"Domain Groups"
"Service Accounts"
"Desktops"
"Terminal Servers"
"Member Servers"
"Mobile Computers"
)
 foreach ($line in $Units){
 New-ADOrganizationalUnit -Name $line -ProtectedFromAccidentalDeletion $False
}
#Create security groups
$dom = (get-ADDomain).DistinguishedName
$list = @(
"ACL_Genapps"
"ACL_Shared"
"ACL_Junk"
)
foreach ($group in $list){
New-ADGroup -Name $group -SamAccountName $group -GroupCategory Security -GroupScope Global -Path "OU=Domain Groups,$dom"
}