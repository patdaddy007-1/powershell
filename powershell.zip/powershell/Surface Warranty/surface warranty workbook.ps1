& C:\Temp\SDTC.exe -warranty "C:\Temp\warrantyinfo-$env:computername.xml"
$WData = (gc C:\Temp\warrantyinfo-ws-039348183253.xml) -match "<EffectiveEndDate>"
$End = [regex]::new('\d.+?(?=T)')
$matches = $end.Matches($WData)
$matches
$matches.value
###########################################
$surfaces = get-adcomputer -Filter * -Properties Name,Description,Enabled|where {$_.Enabled -eq $True}|select Name,Description
$surfaces = $surfaces | where {(($_.Name).Length -gt 10) -AND ($_.Name -like "WS-*") -AND ($_.Name -notlike "*conf*") -AND ($_.Name -notlike "*2ua*")}
$surfaces = $surfaces | where {($_.Name -notlike "*conf*") -AND ($_.Name -notlike "*2ua*")}


###########################################
Set-WmiInstance -Class win32_environment -Argument @{Name="EndWarranty";VariableValue="2018-01-01";UserName=""}
###########################################
###########################################

###########################################
# This section creates the reg key and value for later pulls
#HKEY_LOCAL_MACHINE\HARDWARE\DESCRIPTION\System
& C:\Temp\SDTC.exe -warranty "C:\Temp\warrantyinfo-$env:computername.xml"
$WData = (gc "C:\Temp\warrantyinfo-$env:computername.xml") -match "<EffectiveEndDate>"
$End = [regex]::new('\d.+?(?=T)')
$matches = $end.Matches($WData)
New-ItemProperty -Path HKLM:\HARDWARE\DESCRIPTION\System -Name EndOfWarranty
Set-ItemProperty -Path HKLM:\HARDWARE\DESCRIPTION\System -Name EndOfWarranty -Value $matches.value
###########################################
###########################################
$SFile = "C:\Temp\SDTC.exe"
$Dest = "\\$test\C$\Temp\SDTC.exe"
foreach ($S in $surfaces){
$name = $S.Name
$path = "\\$Name\C$\Temp\"
copy-item $SFile $path
}
###########################################
###########################################
$RegistryHive = 'LocalMachine'
$RegistryKeyPath = 'HARDWARE\DESCRIPTION\System'
$ValueName = 'EndOfWarranty'
$report = @()
foreach ($C in $computers){
IF (Test-Connection $C -Count 2 -Quiet){
$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($RegistryHive, $C)
$key = $reg.OpenSubKey($RegistryKeyPath)
$Data = $key.GetValue($ValueName)
$Obj = New-Object psobject
$Obj | Add-Member -Name "Computer Name" -MemberType NoteProperty -Value $C
$Obj | Add-Member -Name "Warranty End Date" -MemberType NoteProperty -Value $Data
$report += $obj
}
else {
Write-Host "$C not reachable" -BackgroundColor DarkRed
}
}
###########################################
###########################################
foreach ($S in $Surfaces){
Write-Host "$S.Name warranty ends"
invoke-command -Computername $S.Name -ScriptBlock {(Get-ItemProperty -Path HKLM:\HARDWARE\DESCRIPTION\System).EndOfWarranty}
}

