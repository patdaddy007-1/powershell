#Define script variables
$DellAPIURL = "https://apigtwb2c.us.dell.com/PROD/sbil/eapi/v5/asset-entitlements"
$DellAPIKey      = "l75ebe2cd1bd3a44ff91d8f0be2faddb59"
$APIKeySecret    = 'd1bc9d4477fd449494a4a31f3ac11405'
$headers = @{
            Accept = "application/json"
            Authorization = "Bearer $script:token"
        }
$params = @{ servicetags = $ServiceTags -join ','}
$Tagarray = @()
$computers = get-adcomputer -Filter * -Properties Name,Description,Enabled|where {$_.Enabled -eq $True}|select Name,Description

$NewFileName = "Dell Warranty Report"+(Get-Date -Format MM-yyyy)+".csv"
$props=[ordered]@{
     Workstation=''
	 Serial=''
	 Description=''
     Expires=''
}
New-Object PsObject -Property $props | Export-Csv C:\Temp\$NewFileName -NoTypeInformation
#build list of service tags
#First, the enabled and online systems pulled from AD
#script functions
Function Get-Token {
$AuthURI      = "https://apigtwb2c.us.dell.com/auth/oauth/v2/token"
    $OAuth        = "$DellAPIKey`:$APIKeySecret"
    $Bytes        = [System.Text.Encoding]::ASCII.GetBytes($OAuth)
    $EncodedOAuth = [Convert]::ToBase64String($Bytes)

    $Headers = @{ }
    $Headers.Add("authorization", "Basic $EncodedOAuth")
    $Authbody = 'grant_type=client_credentials'
    
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    
    Try {
        $AuthResult = Invoke-RESTMethod -Method Post -Uri $AuthURI -Body $AuthBody -Headers $Headers
        $script:token = $AuthResult.access_token
    }
    Catch {
        $ErrorMessage = $Error[0]
        Write-Error $ErrorMessage
        BREAK        
    }
    Write-Verbose "Access Token is: $script:token"
}
Function Invoke-DellAPILookup {
param([string[]] $ServiceTags)
$headers = @{
Accept = "application/json"
Authorization = "Bearer $script:token"
}
$params = @{ servicetags = $ServiceTags -join ','}
$lookup = Invoke-RestMethod -Uri $DellAPIURL -Headers $headers -Body $params -Method Get -ContentType "application/json"
return $lookup
}

#Get authentication token for API call
. Get-Token
#process service tags and output warranty information
foreach ($C in $computers){
IF ([bool](Test-Connection $C.Name -Count 1 -EA 0)){
$wmidata = Get-WmiObject -ComputerName $C.Name -Class win32_bios -EA 0
if ($wmidata.Manufacturer -like "Dell*"){$Tag = $wmidata.SerialNumber}
}
IF ($C.Name -match "WS-.......$"){$Tag = $C.Name -replace "WS-",""}
IF ($Tag -ne $null){
$sdata = Invoke-DellAPILookup -ServiceTags $tag
$sdata | Select @{Name="Workstation";Expression={$C.Name}},@{Name="Serial";Expression={$Tag}},@{Name="Description";Expression={$C.Description}},@{Name="Expires";Expression={($sdata.Entitlements.EndDate|sort -Descending|select -First 1) -replace  "T\d\d:.+",""}}|Export-Csv C:\Temp\$NewFileName -NoTypeInformation -Append
}
}
