$RegPresent = [bool](get-Itemproperty -path 'HKLM:\SOFTWARE\Duo Security\DuoCredProv' -Name 'ProvidersWhitelist' -EA 0)

function enable-duo {
Remove-ItemProperty -path 'HKLM:\SOFTWARE\Duo Security\DuoCredProv' ProvidersWhitelist
}

function disable-duo {
New-Itemproperty -path 'HKLM:\SOFTWARE\Duo Security\DuoCredProv' -PropertyType MultiString -Name 'ProvidersWhitelist' -value '{60B78E88-EAD8-445C-9CFD-0B87F74EA6CD}'
}

IF ($RegPresent){
enable-duo
write-host "Duo has been enabled"
} ELSE {
disable-duo
write-host "Duo has been disabled"
}