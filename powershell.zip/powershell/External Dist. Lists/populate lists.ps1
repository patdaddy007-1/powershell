$ExtUsers = Get-EXORecipient | where {($_.RecipientType -eq "MailContact") -AND ($_.Identity -ne "fmc@cummingsaerospace.com")} | select *
foreach ($U in $ExtUsers){
$UName = $U.DisplayName -replace " - .+",""
$UEmail = $U.PrimarySmtpAddress
$DName = ((Get-ADUser -Filter * -Properties *  |where {$_.displayname -eq $UName} | select -Expandproperty DistinguishedName) -replace "^([^,]+),OU=","") -replace ",.+$",""
switch ($DName){
'AL-Huntsville' {$DstLst = "CA-EXT-Huntsville"}
'FL-Largo' {$DstLst = "CA-EXT-Largo"}
'FL-Niceville' {$DstLst = "CA-EXT-Niceville"}
}
Add-DistributionGroupMember -Identity $DstLst -Member $UEmail
}
