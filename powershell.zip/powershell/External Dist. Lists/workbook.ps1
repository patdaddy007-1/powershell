$mailboxes = gc D:\Temp\nv1mail.txt
foreach ($user in $mailboxes){
Add-DistributionGroupMember -Identity "Niceville Print Users" -Member "$user"
}


$ExtUsers = Get-EXORecipient | where {$_.RecipientType -eq "MailContact"} | select -expandproperty name
$ExtUsers = Get-EXORecipient | where {$_.RecipientType -eq "MailContact"} | select *
$ExUsersSlim = $ExtUsers -replace " - .+",""
$XTUserList = $ExUsersSlim| Get-Unique






$ExtUsers.PrimarySmtpAddress

$ExtUsers = Get-EXORecipient | where {($_.RecipientType -eq "MailContact") -AND ($_.Identity -ne "fmc@cummingsaerospace.com")} | select *
$XTUserList = $ExtUsers.Identity -replace " - .+",""| Get-Unique
foreach ($U in $ExtUsers){
$UName = $U.DisplayName -replace " - .+",""
$UEmail = $U.PrimarySmtpAddress
$DName = ((Get-ADUser -Filter * -Properties *  |where {$_.displayname -eq $UName} | select -Expandproperty DistinguishedName) -replace "^([^,]+),OU=","") -replace ",.+$",""
switch ($DName){
'AL-Huntsville' {$DstLst = "CA-EXT-Huntsville"}
'FL-Largo' {$DstLst = "CA-EXT-Largo"}
'FL-Niceville' {$DstLst = "CA-EXT-Niceville"}
}
Add-DistributionGroupMember -Identity $DstLst -Member $UEmail
}



switch ($DName){
'AL-Huntsville' {$DstLst = "CA-EXT-Huntsville"}
'FL-Largo' {$DstLst = "CA-EXT-Largo"}
'FL-Niceville' {$DstLst = "CA-EXT-Niceville"}
}

/.*?(?=,|$)/
$DNList = New-Object System.Collections.ArrayList
foreach ($U in $ExtUsers){
$UName = $U.DisplayName -replace " - .+",""
$UEmail = $U.PrimarySmtpAddress
$DName = ((Get-ADUser -Filter * -Properties *  |where {$_.displayname -eq $UName} | select -Expandproperty DistinguishedName) -replace "^([^,]+),OU=","") -replace ",.+$",""
$DNList.Add($DName)
}


$DNList -replace ",.+$",""

<# 
$Groups = @(
"CA-EXT-Niceville"
"CA-EXT-Largo"
"CA-EXT-Huntsville"
)
foreach ($G in $Groups){
New-DistributionGroup $G -alias $G
} #>