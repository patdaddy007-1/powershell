$state = Get-ADUser Cbigoney -Properties *|select -ExpandProperty LockedOut
DO{
if ($state = "False"){
"Account is unlocked"
Start-Sleep -s 5
$state = Get-ADUser Cbigoney -Properties *|select -ExpandProperty LockedOut
} else {
 "account locked out"
 get-date
}} While ($state = "False")
function codyfix{
IF ((Get-ADUser Cbigoney -Properties *|select -ExpandProperty LockedOut)-eq $True){
$Stamp = Get-Date
"Locked. Unlocking now $Stamp" 
Unlock-ADAccount "CBigoney"
} ELSE {
$Stamp = Get-Date
"Unlocked as of $Stamp"
}}

do{
codyfix
Start-Sleep -s 60
} while ($true)