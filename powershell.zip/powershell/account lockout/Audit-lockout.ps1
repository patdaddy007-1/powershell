$id = Read-Host -Prompt "Enter ID: "

$DCs = Get-ADDomainController -Filter * | Select-Object name
$FormattedDCs = $DCs -replace("@{name=","") -replace ("}",".ca.local")


#write-host $FormattedDCs
foreach ($DC in $FormattedDCs) {

$user = Get-ADUser $ID -Properties cn, LockedOut, pwdLastSet, `
badPwdCount, badPasswordTime, lastLogon, lastLogoff, lastLogonTimeStamp, `
whenCreated, whenChanged -server $DC

write-host $DC
$user |
    Select-Object cn, `
    @{name='pwdLastSetDT'; `
        expression={[datetime]::fromFileTime($_.pwdlastset)}}, `
    @{name='badPasswordTimeDT'; `
        expression={[datetime]::fromFileTime($_.badPasswordTime)}}, `
    @{name='lastLogonDT'; `
        expression={[datetime]::fromFileTime($_.lastLogon)}}, `
    @{name='lastLogonTimestampDT'; `
        expression={[datetime]::fromFileTime($_.lastLogonTimestamp)}}, `
    whenCreated, `
    whenChanged
}